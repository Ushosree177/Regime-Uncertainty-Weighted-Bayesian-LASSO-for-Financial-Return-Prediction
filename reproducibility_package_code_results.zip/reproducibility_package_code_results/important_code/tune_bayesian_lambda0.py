"""Choose one Bayesian-LASSO shrinkage scale using validation data only.

Plain-language idea
-------------------
The Bayesian LASSO's lambda controls how strongly coefficients are pulled
toward zero. We try the same small log-scale grid for every Bayesian model,
score only on the validation period, and select one shared value. The test
period is not used here. Run this script before the final comparison, then use
the reported shared value in robust_real_data_validation.py.

Run from the project folder:
    python important_code/tune_bayesian_lambda0.py

The Gibbs sampler and preprocessing are reused from the main project code so
the calibration follows the model equations used in the paper.
"""

from pathlib import Path
import json

import numpy as np
import pandas as pd
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import StandardScaler

from bayesian_lasso_experiment import BayesianLassoGibbs
from robust_real_data_validation import (
    DATA_DIR,
    FEATURE_COLUMNS,
    REGIME_ORDER,
    TARGET_COLUMN,
    MAX_GLOBAL_TRAIN_ROWS,
    MAX_REGIME_TRAIN_ROWS,
    RANDOM_STATE,
    add_research_features,
    calculate_feature_evidence,
    calculate_regime_uncertainty,
    load_data,
    prepare_model_data,
    relabel_split_with_train_hmm,
    sample_rows,
    split_train_validation_test,
)
from simulation_study import WeightedBayesianLassoGibbs


OUTPUT_DIR = DATA_DIR / "bayesian_lambda0_tuning"
# A finer grid avoids letting a tenfold jump dominate modest adaptive weights.
LAMBDA0_GRID = np.geomspace(100, 1_000_000, 15).tolist()
GAMMA = 1.0
DELTA = 0.1
EPSILON = 0.001
GAMMA_GRID = [0.0, 0.5, 1.0, 2.0]
DELTA_GRID = [0.0, 0.01, 0.05, 0.1, 0.5, 1.0, 2.0]
ITERATIONS = 500
BURN_IN = 200
THIN = 5


def scale_and_fit(train, validation, model, seed):
    """Scale from training data, fit one sampler, and return validation errors."""
    sampled_train = sample_rows(train, MAX_GLOBAL_TRAIN_ROWS, seed)
    x_scaler = StandardScaler()
    y_scaler = StandardScaler()
    x_train = x_scaler.fit_transform(sampled_train[FEATURE_COLUMNS])
    x_validation = x_scaler.transform(validation[FEATURE_COLUMNS])
    y_train = y_scaler.fit_transform(sampled_train[[TARGET_COLUMN]]).ravel()
    model.fit(x_train, y_train)
    prediction_scaled = model.predict(x_validation)
    prediction = y_scaler.inverse_transform(prediction_scaled.reshape(-1, 1)).ravel()
    return prediction


def fit_regime_model(train, validation, lambda_by_regime, seed):
    """Fit one Bayesian model per regime and restore original row order."""
    prediction = pd.Series(index=validation.index, dtype=float)
    for regime_number, regime in enumerate(REGIME_ORDER):
        train_regime = train[train["Regime"] == regime]
        validation_regime = validation[validation["Regime"] == regime]
        if train_regime.empty or validation_regime.empty:
            continue

        sampled_train = sample_rows(
            train_regime,
            MAX_REGIME_TRAIN_ROWS,
            seed + regime_number,
        )
        x_scaler = StandardScaler()
        y_scaler = StandardScaler()
        x_train = x_scaler.fit_transform(sampled_train[FEATURE_COLUMNS])
        x_validation = x_scaler.transform(validation_regime[FEATURE_COLUMNS])
        y_train = y_scaler.fit_transform(sampled_train[[TARGET_COLUMN]]).ravel()

        model = WeightedBayesianLassoGibbs(
            lambda_values=lambda_by_regime[regime],
            n_iterations=ITERATIONS,
            burn_in=BURN_IN,
            thin=THIN,
            random_state=seed + 100 + regime_number,
        )
        model.fit(x_train, y_train)
        prediction_scaled = model.predict(x_validation)
        prediction.loc[validation_regime.index] = y_scaler.inverse_transform(
            prediction_scaled.reshape(-1, 1)
        ).ravel()
    return prediction


def main():
    """Compare five Bayesian specifications on one untouched validation fold."""
    raw_data = load_data()
    model_data = prepare_model_data(add_research_features(raw_data))
    train, validation, test, _, _ = split_train_validation_test(model_data)

    # The test rows are intentionally not passed to any fitting or scoring call.
    train, validation = relabel_split_with_train_hmm(train, validation)
    uncertainty = calculate_regime_uncertainty(train)
    evidence = calculate_feature_evidence(train)
    u = uncertainty.set_index("Regime")["U_r"]

    rows = []
    for lambda0 in LAMBDA0_GRID:
        print(f"Checking shared lambda0 = {lambda0}")

        # A pooled Bayesian LASSO uses one coefficient vector across regimes.
        pooled_model = BayesianLassoGibbs(
            lambda_value=lambda0,
            n_iterations=ITERATIONS,
            burn_in=BURN_IN,
            thin=THIN,
            random_state=RANDOM_STATE,
        )
        pooled_prediction = scale_and_fit(train, validation, pooled_model, RANDOM_STATE)
        rows.append({
            "Lambda0": lambda0,
            "Bayesian_Model": "Pooled Bayesian LASSO",
            "Validation_RMSE": np.sqrt(mean_squared_error(
                validation[TARGET_COLUMN], pooled_prediction
            )),
        })

        # Compare regime-specific constant shrinkage and the three prior forms.
        for mode in ["constant", "uncertainty_only", "evidence_only", "full"]:
            lambda_by_regime = {}
            for regime in REGIME_ORDER:
                if mode == "constant":
                    multiplier = np.ones(len(FEATURE_COLUMNS))
                elif mode == "uncertainty_only":
                    multiplier = np.full(len(FEATURE_COLUMNS), np.exp(GAMMA * u[regime]))
                elif mode == "evidence_only":
                    multiplier = 1 / (evidence[regime].loc[FEATURE_COLUMNS].to_numpy() + EPSILON) ** DELTA
                else:
                    multiplier = (
                        np.exp(GAMMA * u[regime])
                        / (evidence[regime].loc[FEATURE_COLUMNS].to_numpy() + EPSILON) ** DELTA
                    )
                lambda_by_regime[regime] = lambda0 * multiplier

            prediction = fit_regime_model(
                train, validation, lambda_by_regime, RANDOM_STATE
            )
            rows.append({
                "Lambda0": lambda0,
                "Bayesian_Model": f"Regime-specific {mode.replace('_', ' ')}",
                "Validation_RMSE": np.sqrt(mean_squared_error(
                    validation.loc[prediction.notna(), TARGET_COLUMN],
                    prediction.dropna(),
                )),
            })

    scores = pd.DataFrame(rows)
    # One common value is chosen by averaging validation RMSE across the five
    # Bayesian model forms, so every model gets the same lambda0 afterward.
    shared_scores = scores.groupby("Lambda0")["Validation_RMSE"].mean()
    chosen_lambda0 = float(shared_scores.idxmin())

    # With the common scale fixed, tune the full prior's two adaptation
    # controls on the same validation period. The test period stays untouched.
    full_grid_rows = []
    for gamma in GAMMA_GRID:
        for delta in DELTA_GRID:
            print(f"Checking gamma={gamma:g}, delta={delta:g} at shared lambda0={chosen_lambda0}")
            lambda_by_regime = {}
            for regime in REGIME_ORDER:
                lambda_by_regime[regime] = chosen_lambda0 * (
                    np.exp(gamma * u[regime])
                    / (evidence[regime].loc[FEATURE_COLUMNS].to_numpy() + EPSILON) ** delta
                )
            prediction = fit_regime_model(
                train, validation, lambda_by_regime,
                RANDOM_STATE + int(gamma * 100) + int(delta * 1000),
            )
            full_grid_rows.append({
                "Gamma": gamma,
                "Delta": delta,
                "Lambda0": chosen_lambda0,
                "Validation_RMSE": np.sqrt(mean_squared_error(
                    validation.loc[prediction.notna(), TARGET_COLUMN],
                    prediction.dropna(),
                )),
            })
    full_grid = pd.DataFrame(full_grid_rows).sort_values("Validation_RMSE").reset_index(drop=True)
    chosen_gamma = float(full_grid.iloc[0]["Gamma"])
    chosen_delta = float(full_grid.iloc[0]["Delta"])

    OUTPUT_DIR.mkdir(exist_ok=True)
    scores.to_csv(OUTPUT_DIR / "validation_scores.csv", index=False)
    shared_scores.rename("Mean_Validation_RMSE").to_csv(
        OUTPUT_DIR / "shared_lambda0_choice.csv", header=True
    )
    (OUTPUT_DIR / "selected_lambda0.txt").write_text(
        str(chosen_lambda0), encoding="utf-8"
    )
    full_grid.to_csv(OUTPUT_DIR / "gamma_delta_validation_scores.csv", index=False)
    config = {
        "lambda0": chosen_lambda0,
        "gamma": chosen_gamma,
        "delta": chosen_delta,
        "epsilon": EPSILON,
    }
    (OUTPUT_DIR / "selected_model_config.json").write_text(
        json.dumps(config, indent=2), encoding="utf-8"
    )

    print("\nValidation RMSE by model and lambda0:")
    print(scores.pivot(index="Lambda0", columns="Bayesian_Model", values="Validation_RMSE").round(6))
    print(f"\nChosen shared lambda0: {chosen_lambda0}")
    print(f"Chosen gamma/delta: {chosen_gamma:g}/{chosen_delta:g}")
    print(f"Results saved in: {OUTPUT_DIR}")
    print("Use this shared value for all Bayesian models in the final test run.")


if __name__ == "__main__":
    main()
