"""Test a pooled LASSO that is allowed to use different slopes by regime.

Plain-language purpose
----------------------
The usual pooled LASSO gives every regime the same feature slopes. That can
make a regime-specific method look good when simulated slopes truly differ.
This script gives one pooled LASSO a separate feature-by-regime interaction
for each known simulated regime, then tunes its penalty using training-only
cross-validation. It reuses the exact random seeds and data settings from the
published repeated simulation so its test rows match the existing experiments.
"""

from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.linear_model import LassoCV

from repeated_simulation_study import N_REPLICATIONS, RANDOM_STATE, SCENARIOS
from simulation_study import (
    FEATURE_COLUMNS,
    REGIME_ORDER,
    feature_recovery_scores,
    make_train_test_split,
    metrics,
    sample_rows,
    scale_train_test,
    selected_from_coefficients,
    simulate_dataset,
    true_support_for_regime,
    true_union_support,
    invert_y_scale,
)


OUTPUT_DIR = Path("data") / "pooled_regime_interaction_simulation"
MODEL_NAME = "Pooled LASSO with Regime Interactions"
# Use the complete training split, matching every other estimator.
MAX_TRAIN_ROWS = None
ALPHA_GRID = np.logspace(-4, 0, 35)


def interaction_design(features, regimes):
    """Make one feature column for each feature in each regime.

    For example, Momentum_10 in Bull is a different column from Momentum_10
    in Crisis. The four regime indicator columns give the model separate
    intercepts. The resulting table is still fitted as one pooled LASSO.
    """
    regime_number = {name: index for index, name in enumerate(REGIME_ORDER)}
    codes = np.array([regime_number[name] for name in regimes])
    indicators = np.eye(len(REGIME_ORDER))[codes]
    feature_values = np.asarray(features)
    interactions = (
        feature_values[:, :, None] * indicators[:, None, :]
    ).reshape(len(feature_values), -1)
    return np.column_stack([indicators, interactions])


def fit_one_replication(case_name, samples_per_regime, replication, scenario_number):
    """Simulate one dataset, tune the penalty, and score the held-out rows."""
    seed = RANDOM_STATE + replication * 100 + scenario_number * 10
    data, betas, _, _ = simulate_dataset(case_name, samples_per_regime, seed)
    train_data, test_data = make_train_test_split(data)

    # Fit on the complete training split, just like the other estimators.
    train_sample = sample_rows(train_data, MAX_TRAIN_ROWS, seed)
    x_train, x_test, y_train, y_test, y_scaler = scale_train_test(
        train_sample, test_data
    )
    interaction_train = interaction_design(x_train, train_sample["Regime"])
    interaction_test = interaction_design(x_test, test_data["Regime"])

    # The LASSO penalty is selected by cross-validation using training rows only.
    model = LassoCV(
        alphas=ALPHA_GRID,
        cv=5,
        max_iter=50000,
        random_state=seed,
    )
    model.fit(interaction_train, y_train)
    prediction = invert_y_scale(model.predict(interaction_test), y_scaler)

    score = metrics(y_test, prediction)
    feature_regime_coefficients = model.coef_[len(REGIME_ORDER):].reshape(
        len(FEATURE_COLUMNS), len(REGIME_ORDER)
    )
    recovery_by_regime = []
    for regime_index, regime in enumerate(REGIME_ORDER):
        selected_features = selected_from_coefficients(
            feature_regime_coefficients[:, regime_index]
        )
        recovery_by_regime.append(feature_recovery_scores(
            selected_features, true_support_for_regime(betas, regime)
        ))
    recovery = pd.DataFrame(recovery_by_regime).mean(numeric_only=True).to_dict()
    return {
        "Case": case_name,
        "Samples_Per_Regime": samples_per_regime,
        "Replication": replication,
        "Model": MODEL_NAME,
        "Alpha": float(model.alpha_),
        "Training_Rows": len(train_sample),
        **score,
        **{f"Recovery_{key}": value for key, value in recovery.items()},
    }


def main():
    """Run the interaction comparator across all repeated-simulation settings."""
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    rows = []
    total = N_REPLICATIONS * len(SCENARIOS)
    done = 0

    for scenario_number, (case_name, samples_per_regime) in enumerate(SCENARIOS):
        for replication in range(1, N_REPLICATIONS + 1):
            done += 1
            print(
                f"Fit {done}/{total}: {case_name}, "
                f"{samples_per_regime} per regime, repetition {replication}"
            )
            rows.append(fit_one_replication(
                case_name, samples_per_regime, replication, scenario_number
            ))

    results = pd.DataFrame(rows)
    summary = (
        results.groupby(["Case", "Samples_Per_Regime", "Model"])
        .agg(
            RMSE_Mean=("RMSE", "mean"),
            RMSE_Std=("RMSE", "std"),
            MAE_Mean=("MAE", "mean"),
            R2_Mean=("R2", "mean"),
            Direction_Accuracy_Mean=("Direction_Accuracy", "mean"),
            Alpha_Mean=("Alpha", "mean"),
            Recovery_Precision_Mean=("Recovery_Precision", "mean"),
            Recovery_Recall_Mean=("Recovery_Recall", "mean"),
            Recovery_F1_Mean=("Recovery_F1", "mean"),
            Selected_Count_Mean=("Recovery_Selected_Count", "mean"),
        )
        .reset_index()
    )
    results.to_csv(OUTPUT_DIR / "replication_results.csv", index=False)
    summary.to_csv(OUTPUT_DIR / "summary.csv", index=False)
    print("\nPooled interaction LASSO summary:")
    print(summary.round(4).to_string(index=False))
    print(f"\nSaved results in: {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
