"""Three-year tuning robustness check for the rolling forecast study.

This repeats the rolling evaluation, but selects parameters from the three
calendar years before each test year instead of only the immediately preceding
year. The final five dates of the fitting block and tuning block are purged in
the shared window builder.

Run from the project folder:
    python important_code/rolling_multiyear_tuning.py
"""
from pathlib import Path
import pandas as pd
import rolling_window_validation as rolling

DATA_DIR = Path("data")
OUTPUT_DIR = DATA_DIR / "rolling_multiyear_tuning"
TUNING_YEARS = 3


def main():
    """Run every test year and save the results separately from the main run."""
    rolling.PREDICTION_ROWS.clear()
    raw = rolling.load_data()
    featured = rolling.add_research_features(raw)
    model_data = rolling.prepare_model_data(featured)
    windows = rolling.make_yearly_windows(model_data, tuning_years=TUNING_YEARS)
    print(f"Running {len(windows)} years with {TUNING_YEARS}-year tuning blocks")

    all_rows = []
    for window in windows:
        all_rows.extend(rolling.run_one_window(window))

    results = pd.DataFrame(all_rows)
    summary = rolling.summarize_results(results)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    results.round(6).to_csv(OUTPUT_DIR / "rolling_results.csv", index=False)
    summary.round(6).to_csv(OUTPUT_DIR / "rolling_summary.csv", index=False)
    pd.DataFrame(rolling.PREDICTION_ROWS).to_csv(
        OUTPUT_DIR / "rolling_predictions.csv", index=False
    )
    print("\nThree-year tuning summary")
    print(summary.round(6).to_string(index=False))
    print(f"\nSaved results in {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
