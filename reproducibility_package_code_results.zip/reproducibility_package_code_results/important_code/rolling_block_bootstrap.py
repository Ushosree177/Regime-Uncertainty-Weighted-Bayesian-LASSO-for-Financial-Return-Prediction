"""
Paired annual block-bootstrap uncertainty for rolling-window comparisons.

The rolling validation produces one RMSE value per model and test year. This
script first computes paired annual RMSE differences between two models and
then resamples those annual differences. This preserves the model pairing within
each test year and keeps within-year dependence from overlapping five-day
targets and same-date cross-sectional observations inside the annual block.
"""

from pathlib import Path

import numpy as np
import pandas as pd


DATA_DIR = Path("data")
INPUT_FILE = DATA_DIR / "rolling_window_validation" / "rolling_window_results.csv"
OUTPUT_FILE = DATA_DIR / "rolling_window_validation" / "rolling_window_block_bootstrap.csv"

COMPARISONS = [
    ("Proposed Prior - Full", "Standard Bayesian LASSO"),
    ("Proposed Prior - Full", "Training-Mean Benchmark"),
    ("Proposed Prior - Full", "Elastic Net"),
    ("Proposed Prior - Full", "Classical LASSO"),
    ("Proposed Prior - Full", "Adaptive LASSO"),
    ("Proposed Prior - Full", "Regime-specific LASSO"),
    ("Proposed Prior - Full", "Regime-specific Bayesian LASSO"),
    ("Proposed Prior - Full", "Proposed Prior - Evidence Only"),
    ("Proposed Prior - Full", "Proposed Prior - Uncertainty Only"),
]

N_BOOTSTRAPS = 20000
RANDOM_STATE = 42


def paired_annual_block_bootstrap_interval(differences, rng):
    """Return the mean and empirical 95 percent interval."""
    differences = np.asarray(differences, dtype=float)
    n_blocks = len(differences)
    boot_means = np.empty(N_BOOTSTRAPS)

    for draw in range(N_BOOTSTRAPS):
        sampled = rng.choice(differences, size=n_blocks, replace=True)
        boot_means[draw] = sampled.mean()

    return {
        "Mean_RMSE_Difference": differences.mean(),
        "CI95_Lower": np.quantile(boot_means, 0.025),
        "CI95_Upper": np.quantile(boot_means, 0.975),
        "Blocks": n_blocks,
    }


def main():
    results = pd.read_csv(INPUT_FILE)
    wide = results.pivot(index="Test_Year", columns="Model", values="RMSE")
    rng = np.random.default_rng(RANDOM_STATE)

    rows = []
    for first_model, second_model in COMPARISONS:
        differences = (wide[first_model] - wide[second_model]).dropna()
        row = paired_annual_block_bootstrap_interval(differences, rng)
        row["Comparison"] = f"{first_model} minus {second_model}"
        rows.append(row)

    output = pd.DataFrame(rows)
    output = output[
        [
            "Comparison",
            "Mean_RMSE_Difference",
            "CI95_Lower",
            "CI95_Upper",
            "Blocks",
        ]
    ]

    OUTPUT_FILE.parent.mkdir(exist_ok=True)
    output.to_csv(OUTPUT_FILE, index=False)
    print(output.round(6).to_string(index=False))


if __name__ == "__main__":
    main()
