"""Diebold--Mariano tests for saved, date-level forecast errors.

First run one of the forecasting scripts so it writes a prediction CSV. Then run:

    python important_code/forecast_comparison_tests.py --predictions data/rolling_window_validation/rolling_window_predictions.csv

The test first averages squared errors across tickers on each date. This keeps
same-day cross-sectional dependence together. It then uses a Newey--West
long-run variance with four lags, a conventional choice for a five-day
overlapping forecast horizon. Positive mean loss difference means Model A has
larger squared error than Model B.
"""

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import norm


def hac_mean_test(values, max_lag=4):
    """Test whether the mean of a date-level series differs from zero."""
    values = np.asarray(values, dtype=float)
    values = values[np.isfinite(values)]
    count = len(values)
    if count <= max_lag + 1:
        return np.nan, np.nan

    centered = values - values.mean()
    long_run_variance = np.dot(centered, centered) / count
    for lag in range(1, max_lag + 1):
        covariance = np.dot(centered[lag:], centered[:-lag]) / count
        bartlett_weight = 1 - lag / (max_lag + 1)
        long_run_variance += 2 * bartlett_weight * covariance

    if long_run_variance <= 0:
        return np.nan, np.nan
    standard_error = np.sqrt(long_run_variance / count)
    statistic = values.mean() / standard_error
    two_sided_p = 2 * norm.sf(abs(statistic))
    return statistic, two_sided_p


def compare_models(predictions, max_lag=4):
    """Return pairwise DM comparisons using one mean loss per test date."""
    required = {"Date", "Ticker", "Actual", "Prediction", "Model"}
    missing = required - set(predictions.columns)
    if missing:
        raise ValueError(f"Prediction file is missing columns: {sorted(missing)}")

    data = predictions.copy()
    data["Date"] = pd.to_datetime(data["Date"])
    data["Squared_Error"] = (data["Actual"] - data["Prediction"]) ** 2
    daily_losses = data.groupby(["Date", "Model"])["Squared_Error"].mean().unstack()

    rows = []
    models = list(daily_losses.columns)
    for first_index, model_a in enumerate(models):
        for model_b in models[first_index + 1:]:
            paired = daily_losses[[model_a, model_b]].dropna()
            loss_difference = paired[model_a] - paired[model_b]
            statistic, p_value = hac_mean_test(loss_difference, max_lag=max_lag)
            rows.append({
                "Model_A": model_a,
                "Model_B": model_b,
                "Dates": len(paired),
                "Mean_Squared_Error_Gap_A_minus_B": loss_difference.mean(),
                "DM_HAC_Lag": max_lag,
                "DM_Statistic": statistic,
                "P_Value_Two_Sided": p_value,
            })
    results = pd.DataFrame(rows)
    # Control the false-discovery rate across the all-pairs comparisons.
    valid = results["P_Value_Two_Sided"].notna()
    ordered_indices = results.loc[valid, "P_Value_Two_Sided"].sort_values().index
    number_of_tests = len(ordered_indices)
    ordered_p = results.loc[ordered_indices, "P_Value_Two_Sided"].to_numpy()
    adjusted = ordered_p * number_of_tests / np.arange(1, number_of_tests + 1)
    adjusted = np.minimum.accumulate(adjusted[::-1])[::-1]
    results["P_Value_BH_Adjusted"] = np.nan
    results.loc[ordered_indices, "P_Value_BH_Adjusted"] = np.minimum(adjusted, 1.0)
    return results.sort_values("P_Value_Two_Sided")


def main():
    """Read a prediction file and save the pairwise test table beside it."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--predictions", required=True, help="CSV written by a validation script")
    parser.add_argument("--lag", type=int, default=4, help="HAC lag; default is four for five-day returns")
    args = parser.parse_args()

    input_file = Path(args.predictions)
    predictions = pd.read_csv(input_file)
    results = compare_models(predictions, max_lag=args.lag)
    output_file = input_file.with_name(input_file.stem + "_dm_tests.csv")
    results.to_csv(output_file, index=False)
    print(results.round(6).to_string(index=False))
    print(f"\nSaved: {output_file}")


if __name__ == "__main__":
    main()
