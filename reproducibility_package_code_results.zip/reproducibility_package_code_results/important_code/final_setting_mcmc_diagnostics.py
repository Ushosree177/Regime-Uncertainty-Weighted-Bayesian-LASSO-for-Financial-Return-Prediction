"""Four-chain diagnostics for the final, uncapped real-data model.

Run from the project folder with:
    python important_code/final_setting_mcmc_diagnostics.py

The script follows the primary real-data split, refits and forward-filters the
HMM, uses every eligible training row, and applies the selected lambda, gamma,
delta, and epsilon. It writes one compact diagnostics CSV for the paper.
"""

from pathlib import Path
import json
import sys

import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "important_code"))

import robust_real_data_validation as real  # noqa: E402
from multi_chain_mcmc_diagnostics import (  # noqa: E402
    folded_rank_normalized_split_rhat,
    pooled_ess_proxy,
    rank_normalized_split_rhat,
)
from simulation_study import WeightedBayesianLassoGibbs  # noqa: E402


CHAINS = 4
SEEDS = [42, 142, 242, 342]
# Longer diagnostic-only chains: 4,000 iterations, 1,000 burn-in, then
# retain every fifth draw (600 saved draws per chain).
DIAGNOSTIC_ITERATIONS = 4000
DIAGNOSTIC_BURN_IN = 1000
DIAGNOSTIC_THIN = 5
OUTPUT = ROOT / "data" / "robust_real_data_validation" / "final_four_chain_mcmc_diagnostics.csv"


def load_final_training_data():
    """Recreate the training sample used in the primary fixed-split analysis."""
    config_path = ROOT / "data" / "bayesian_lambda0_tuning" / "selected_model_config.json"
    config = json.loads(config_path.read_text(encoding="utf-8"))
    real.LAMBDA_0 = float(config["lambda0"])
    real.GAMMA = float(config["gamma"])
    real.DELTA = float(config["delta"])
    real.EPSILON = float(config["epsilon"])

    raw = real.load_data()
    model_data = real.prepare_model_data(real.add_research_features(raw))
    train, validation, test, _, _ = real.split_train_validation_test(model_data)
    train = pd.concat([train, validation], ignore_index=True)
    train, _ = real.relabel_split_with_train_hmm(train, test)

    uncertainty = real.calculate_regime_uncertainty(train)
    evidence = real.calculate_feature_evidence(train)
    lambdas = real.calculate_lambda_matrix(uncertainty, evidence, "full")
    return train, config, lambdas


def run_one_chain(x, y, lambda_values, seed):
    """Fit one chain from its own dispersed starting values."""
    rng = np.random.default_rng(seed)
    model = WeightedBayesianLassoGibbs(
        lambda_values=lambda_values,
        n_iterations=DIAGNOSTIC_ITERATIONS,
        burn_in=DIAGNOSTIC_BURN_IN,
        thin=DIAGNOSTIC_THIN,
        random_state=seed,
    )
    model.initial_beta = rng.normal(0.0, 0.2, size=x.shape[1])
    model.initial_tau_squared = rng.lognormal(0.0, 0.5, size=x.shape[1])
    model.initial_sigma_squared = float(rng.lognormal(0.0, 0.5))
    model.fit(x, y)
    return model.beta_samples_, model.sigma_squared_samples_


def diagnose_model(model_name, regime, subset, lambda_values, config):
    """Fit four chains and summarize diagnostics for one model and sample."""
    x = StandardScaler().fit_transform(subset[real.FEATURE_COLUMNS])
    y = StandardScaler().fit_transform(subset[[real.TARGET_COLUMN]]).ravel()
    beta_chains, sigma_chains = [], []
    for seed in SEEDS:
        print(f"{model_name} / {regime}: chain seed {seed}")
        beta, sigma = run_one_chain(x, y, lambda_values, seed)
        beta_chains.append(beta)
        sigma_chains.append(sigma)

    beta_chains = np.asarray(beta_chains)
    sigma_chains = np.asarray(sigma_chains)
    beta_rhat = rank_normalized_split_rhat(beta_chains)
    beta_folded = folded_rank_normalized_split_rhat(beta_chains)
    beta_ess = pooled_ess_proxy(beta_chains)
    sigma_rhat = rank_normalized_split_rhat(sigma_chains)
    sigma_folded = folded_rank_normalized_split_rhat(sigma_chains)
    sigma_ess = pooled_ess_proxy(sigma_chains)

    return {
        "Model": model_name,
        "Regime": regime,
        "Rows_Used": len(subset),
        "Features": len(real.FEATURE_COLUMNS),
        "Lambda0": config["lambda0"],
        "Gamma": config["gamma"],
        "Delta": config["delta"],
        "Epsilon": config["epsilon"],
        "Chains": CHAINS,
        "Iterations": DIAGNOSTIC_ITERATIONS,
        "Burn_In": DIAGNOSTIC_BURN_IN,
        "Thin": DIAGNOSTIC_THIN,
        "Saved_Draws_Per_Chain": beta_chains.shape[1],
        "Max_Beta_Rank_Split_Rhat": float(np.nanmax(beta_rhat)),
        "Max_Beta_Folded_Rank_Split_Rhat": float(np.nanmax(beta_folded)),
        "Min_Beta_ESS_Proxy": float(np.nanmin(beta_ess)),
        "Median_Beta_ESS_Proxy": float(np.nanmedian(beta_ess)),
        "Sigma_Squared_Rank_Split_Rhat": float(sigma_rhat[0]),
        "Sigma_Squared_Folded_Rank_Split_Rhat": float(sigma_folded[0]),
        "Sigma_Squared_ESS_Proxy": float(sigma_ess[0]),
    }


def main():
    train, config, lambda_matrix = load_final_training_data()
    rows = []
    print(f"Selected settings: {config}")
    print(f"Training rows: {len(train):,}; using all eligible rows; chains: {CHAINS}")

    # Check the pooled Bayesian baseline with the same selected global lambda.
    pooled_lambda = np.full(len(real.FEATURE_COLUMNS), float(config["lambda0"]))
    rows.append(diagnose_model("Standard Bayesian LASSO", "All", train, pooled_lambda, config))

    for regime in real.REGIME_ORDER:
        subset = train.loc[train["Regime"] == regime].copy()
        if subset.empty:
            continue
        constant_lambda = np.full(len(real.FEATURE_COLUMNS), float(config["lambda0"]))
        full_lambda = lambda_matrix[regime].loc[real.FEATURE_COLUMNS].to_numpy(dtype=float)
        rows.append(diagnose_model("Regime-specific Bayesian LASSO", regime, subset, constant_lambda, config))
        rows.append(diagnose_model("Proposed Prior - Full", regime, subset, full_lambda, config))

    result = pd.DataFrame(rows)
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(OUTPUT, index=False)
    print(result.round(4).to_string(index=False))
    print(f"Saved: {OUTPUT}")


if __name__ == "__main__":
    main()
