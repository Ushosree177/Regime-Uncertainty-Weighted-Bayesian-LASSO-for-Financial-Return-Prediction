"""
Rolling-window validation for the real-data experiment.

Purpose:

The earlier real-data experiment used one fixed train-test split. This script
adds a walk-forward validation design, which is more appropriate for financial
forecasting.

For each test year:

    Train on all years before the test year
    Test on the selected year

Models compared:

1. Classical LASSO
2. Elastic Net
3. Adaptive LASSO
4. Regime-specific LASSO
5. Proposed Prior - Full

The output answers:

    Are the conclusions stable across time?
"""

from pathlib import Path
import json

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import robust_real_data_validation as validation_pipeline

from robust_real_data_validation import (
    FEATURE_COLUMNS,
    REGIME_ORDER,
    PREDICTION_ROWS,
    TARGET_COLUMN,
    RANDOM_STATE,
    add_research_features,
    calculate_feature_evidence,
    calculate_lambda_matrix,
    calculate_regime_uncertainty,
    load_data,
    prepare_model_data,
    train_adaptive_lasso,
    train_elastic_net,
    train_lasso,
    train_regime_bayesian_model,
    train_regime_lasso,
    train_standard_bayesian_lasso,
    training_mean_benchmark,
    relabel_split_with_train_hmm,
    scale_train_test,
    invert_y_scale,
)
from simulation_study import WeightedBayesianLassoGibbs


DATA_DIR = Path("data")
OUTPUT_DIR = DATA_DIR / "rolling_window_validation"

START_TEST_YEAR = 2015
END_TEST_YEAR = 2025
MIN_TRAIN_ROWS = 20000
PURGE_TRADING_DAYS = 5


def make_yearly_windows(model_data, tuning_years=1):
    """Create expanding test windows with a one- or multi-year tuning block."""
    windows = []

    for test_year in range(START_TEST_YEAR, END_TEST_YEAR + 1):
        # Keep the years immediately before the test year for tuning. The final
        # model is later refit using both the earlier history and this block.
        train_data = model_data[model_data["Date"].dt.year < test_year - tuning_years].copy()
        validation_data = model_data[
            (model_data["Date"].dt.year >= test_year - tuning_years)
            & (model_data["Date"].dt.year < test_year)
        ].copy()
        test_data = model_data[model_data["Date"].dt.year == test_year].copy()

        # The target uses the next five trading days. Remove the final five
        # training dates so their target windows cannot overlap the test year.
        training_dates = np.array(sorted(train_data["Date"].unique()))
        validation_dates = np.array(sorted(validation_data["Date"].unique()))
        if len(training_dates) >= PURGE_TRADING_DAYS:
            train_data = train_data[
                ~train_data["Date"].isin(training_dates[-PURGE_TRADING_DAYS:])
            ].copy()
        # Validation outcomes must also be fully observed before the test year.
        if len(validation_dates) >= PURGE_TRADING_DAYS:
            validation_data = validation_data[
                ~validation_data["Date"].isin(validation_dates[-PURGE_TRADING_DAYS:])
            ].copy()

        if len(train_data) < MIN_TRAIN_ROWS or validation_data.empty or test_data.empty:
            continue

        windows.append(
            {
                "Test_Year": test_year,
                "Train_Data": train_data,
                "Validation_Data": validation_data,
                "Test_Data": test_data,
                "Tuning_Years": tuning_years,
            }
        )

    return windows


def tune_bayesian_weights(train_data, validation_data, test_year):
    """Choose shrinkage settings using only this window's training and validation years."""
    uncertainty = calculate_regime_uncertainty(train_data)
    evidence = calculate_feature_evidence(train_data)
    candidates = [
        (lambda0, gamma, delta)
        for lambda0 in (100.0, 1000.0, 10000.0, 100000.0, 1000000.0)
        for gamma in (0.0, 0.5)
        for delta in (0.0, 0.05, 0.5)
    ]
    best = (float("inf"), 1000.0, 0.0, 0.0)
    original_settings = (
        validation_pipeline.MCMC_ITERATIONS,
        validation_pipeline.BURN_IN,
        validation_pipeline.THIN,
    )
    # Short chains keep the calibration search practical. Final models use the
    # full chain settings restored below.
    validation_pipeline.MCMC_ITERATIONS = 250
    validation_pipeline.BURN_IN = 100
    validation_pipeline.THIN = 5
    try:
        for lambda0, gamma, delta in candidates:
            validation_pipeline.GAMMA = gamma
            validation_pipeline.DELTA = delta
            predictions = []
            for regime_index, regime in enumerate(REGIME_ORDER):
                regime_train = train_data[train_data["Regime"] == regime]
                regime_validation = validation_data[validation_data["Regime"] == regime]
                if regime_train.empty or regime_validation.empty:
                    continue
                x_train, x_valid, y_train, _, y_scaler = scale_train_test(
                    regime_train, regime_validation
                )
                lambdas = calculate_lambda_matrix(
                    uncertainty, evidence, "full", lambda_0=lambda0
                )[regime].loc[FEATURE_COLUMNS].to_numpy()
                model = WeightedBayesianLassoGibbs(
                    lambda_values=lambdas,
                    n_iterations=250,
                    burn_in=100,
                    thin=5,
                    random_state=RANDOM_STATE + test_year + regime_index,
                )
                model.fit(x_train, y_train)
                prediction = invert_y_scale(model.predict(x_valid), y_scaler)
                frame = regime_validation[["Date", "Ticker", TARGET_COLUMN]].copy()
                frame["Prediction"] = prediction
                predictions.append(frame)
            if not predictions:
                continue
            scored = pd.concat(predictions, ignore_index=True)
            score = float(np.sqrt(np.mean((scored[TARGET_COLUMN] - scored["Prediction"]) ** 2)))
            if score < best[0]:
                best = (score, lambda0, gamma, delta)
    finally:
        (validation_pipeline.MCMC_ITERATIONS,
         validation_pipeline.BURN_IN,
         validation_pipeline.THIN) = original_settings
    return float(best[1]), float(best[2]), float(best[3])


def run_one_window(window):
    """Run all selected models for one test year."""
    test_year = window["Test_Year"]
    tuning_years = window.get("Tuning_Years", 1)
    train_data = window["Train_Data"]
    validation_data = window["Validation_Data"]
    test_data = window["Test_Data"]

    # Tune all baseline settings on the immediately preceding year.
    tuning_train, tuning_validation = relabel_split_with_train_hmm(
        train_data, validation_data
    )
    validation_pipeline.LINEAR_TUNING.clear()
    validation_pipeline.tune_linear_baselines(tuning_train, tuning_validation)

    # Tune the Bayesian prior on a small, declared grid. This is a calibration
    # stage only; the test year is never used to choose these values.
    chosen_lambda, chosen_gamma, chosen_delta = tune_bayesian_weights(
        tuning_train, tuning_validation, test_year
    )
    final_training = pd.concat([train_data, validation_data], ignore_index=True)
    final_training, test_data = relabel_split_with_train_hmm(final_training, test_data)
    train_data = final_training
    validation_pipeline.LAMBDA_0 = chosen_lambda
    validation_pipeline.GAMMA = chosen_gamma
    validation_pipeline.DELTA = chosen_delta
    print(f"\nRolling window test year: {test_year}")
    first_validation_year = test_year - tuning_years
    validation_span = (
        str(first_validation_year)
        if tuning_years == 1
        else f"{first_validation_year}--{test_year - 1}"
    )
    print(f"Validation years: {validation_span}; selected lambda0={chosen_lambda:g}, gamma={chosen_gamma:g}, delta={chosen_delta:g}")
    print(f"Training rows: {len(train_data)}")
    print(f"Testing rows: {len(test_data)}")

    selected_rows = []
    result_rows = []

    result_rows.append(training_mean_benchmark(train_data, test_data))

    result_rows.append(train_lasso(train_data, test_data, selected_rows))
    result_rows.append(train_elastic_net(train_data, test_data, selected_rows))
    result_rows.append(train_adaptive_lasso(train_data, test_data, selected_rows))
    result_rows.append(train_regime_lasso(train_data, test_data, selected_rows))

    uncertainty = calculate_regime_uncertainty(train_data)
    evidence = calculate_feature_evidence(train_data)

    result_rows.append(train_standard_bayesian_lasso(train_data, test_data, selected_rows))

    model_specs = [
        ("constant", "Regime-specific Bayesian LASSO"),
        ("uncertainty_only", "Proposed Prior - Uncertainty Only"),
        ("evidence_only", "Proposed Prior - Evidence Only"),
        ("full", "Proposed Prior - Full"),
    ]
    for mode, model_name in model_specs:
        lambda_matrix = calculate_lambda_matrix(uncertainty, evidence, mode)
        result_rows.append(
            train_regime_bayesian_model(
                train_data, test_data, selected_rows, lambda_matrix, model_name
            )
        )

    for row in result_rows:
        row["Test_Year"] = test_year
        row["Tuning_Years"] = tuning_years
        row["Train_Rows"] = len(train_data)
        row["Window_Test_Rows"] = len(test_data)
        if "Bayesian" in row["Model"] or "Proposed Prior" in row["Model"]:
            row["Lambda0"] = validation_pipeline.LAMBDA_0
            row["Gamma"] = validation_pipeline.GAMMA if "Proposed Prior" in row["Model"] else np.nan
            row["Delta"] = validation_pipeline.DELTA if "Proposed Prior" in row["Model"] else np.nan

    return result_rows


def summarize_results(results):
    """Create mean and standard deviation by model."""
    summary = (
        results.groupby("Model")
        .agg(
            RMSE_Mean=("RMSE", "mean"),
            RMSE_Std=("RMSE", "std"),
            MAE_Mean=("MAE", "mean"),
            MAE_Std=("MAE", "std"),
            R2_Mean=("R2", "mean"),
            R2_Std=("R2", "std"),
            Direction_Accuracy_Mean=("Direction_Accuracy", "mean"),
            Direction_Accuracy_Std=("Direction_Accuracy", "std"),
            R2_Expanding_Mean_Average=("R2_Expanding_Mean", "mean"),
            R2_Expanding_Mean_Std=("R2_Expanding_Mean", "std"),
            Always_Up_Accuracy_Mean=("Always_Up_Accuracy", "mean"),
            Windows=("Test_Year", "nunique"),
        )
        .reset_index()
    )

    return summary.sort_values("RMSE_Mean").reset_index(drop=True)


def plot_rmse_by_year(results):
    """Create a time-series plot of RMSE by model."""
    output_file = OUTPUT_DIR / "rolling_window_rmse_by_year.png"

    plt.figure(figsize=(11, 6))

    for model, group in results.groupby("Model"):
        group = group.sort_values("Test_Year")
        plt.plot(group["Test_Year"], group["RMSE"], marker="o", linewidth=1.6, label=model)

    plt.title("Rolling-Window RMSE by Test Year")
    plt.xlabel("Test Year")
    plt.ylabel("RMSE")
    plt.legend(fontsize=8)
    plt.tight_layout()
    plt.savefig(output_file, dpi=200)
    plt.close()

    return output_file


def write_interpretation(results, summary):
    """Write a concise interpretation file."""
    interpretation_file = OUTPUT_DIR / "rolling_window_interpretation.txt"

    best_model = summary.iloc[0]["Model"]
    proposed = summary[summary["Model"] == "Proposed Prior - Full"]

    lines = []
    lines.append("ROLLING-WINDOW VALIDATION INTERPRETATION")
    lines.append("")
    lines.append(f"Test years: {START_TEST_YEAR} to {END_TEST_YEAR}")
    lines.append("")
    lines.append("Average performance across windows:")
    lines.append(summary.round(6).to_string(index=False))
    lines.append("")
    lines.append(f"Best average RMSE model: {best_model}")

    if not proposed.empty:
        proposed_row = proposed.iloc[0]
        lines.append(
            f"Proposed prior average RMSE: {proposed_row['RMSE_Mean']:.6f} "
            f"+/- {proposed_row['RMSE_Std']:.6f}"
        )

    lines.append("")
    lines.append("Research meaning:")
    lines.append(
        "Rolling-window validation checks whether the fixed train-test result is "
        "stable across different market periods."
    )
    lines.append(
        "If the proposed prior remains close to simpler sparse baselines, but does "
        "not dominate, this supports the earlier conclusion that real data has "
        "weaker regime-dependent structure than the strong simulation scenario."
    )

    interpretation_file.write_text("\n".join(lines), encoding="utf-8")
    return interpretation_file


def save_outputs(results):
    """Save rolling-window outputs."""
    OUTPUT_DIR.mkdir(exist_ok=True)

    summary = summarize_results(results)

    results_file = OUTPUT_DIR / "rolling_window_results.csv"
    summary_file = OUTPUT_DIR / "rolling_window_summary.csv"
    prediction_file = OUTPUT_DIR / "rolling_window_predictions.csv"
    plot_file = plot_rmse_by_year(results)
    interpretation_file = write_interpretation(results, summary)

    results.round(6).to_csv(results_file, index=False)
    summary.round(6).to_csv(summary_file, index=False)
    pd.DataFrame(PREDICTION_ROWS).to_csv(prediction_file, index=False)

    return {
        "results": results_file,
        "summary": summary_file,
        "predictions": prediction_file,
        "plot": plot_file,
        "interpretation": interpretation_file,
    }


def main():
    PREDICTION_ROWS.clear()
    print("ROLLING-WINDOW VALIDATION")

    selected_config_file = DATA_DIR / "bayesian_lambda0_tuning" / "selected_model_config.json"
    selected_lambda_file = DATA_DIR / "bayesian_lambda0_tuning" / "selected_lambda0.txt"
    if selected_config_file.exists():
        config = json.loads(selected_config_file.read_text(encoding="utf-8"))
        validation_pipeline.LAMBDA_0 = float(config["lambda0"])
        validation_pipeline.GAMMA = float(config["gamma"])
        validation_pipeline.DELTA = float(config["delta"])
        validation_pipeline.EPSILON = float(config["epsilon"])
    elif selected_lambda_file.exists():
        validation_pipeline.LAMBDA_0 = float(
            selected_lambda_file.read_text(encoding="utf-8").strip()
        )
    print(
        f"Shared lambda0={validation_pipeline.LAMBDA_0:g}; "
        f"gamma={validation_pipeline.GAMMA:g}; delta={validation_pipeline.DELTA:g}"
    )

    raw_data = load_data()
    data_with_features = add_research_features(raw_data)
    model_data = prepare_model_data(data_with_features)

    windows = make_yearly_windows(model_data)
    print(f"Number of rolling windows: {len(windows)}")

    all_rows = []
    for window in windows:
        all_rows.extend(run_one_window(window))

    results = pd.DataFrame(all_rows)
    outputs = save_outputs(results)
    summary = summarize_results(results)

    print("\nROLLING-WINDOW SUMMARY")
    print(summary.round(6).to_string(index=False))

    print("\nSaved files:")
    for path in outputs.values():
        print(path)


if __name__ == "__main__":
    main()
