# Plain-language guide to the analysis code

This project asks one question: **does estimating a separate model for each market regime improve five-day return forecasts, and does the proposed feature-specific Bayesian shrinkage add anything beyond that?**

The short answer from the current experiments is cautious. Regime-specific fitting helps in simulations when the true coefficients differ by regime. The proposed weighting usually ties its regime-specific Bayesian baseline in those simulations. On the financial data, the forecasts are very close to an expanding historical-average forecast or the always-up benchmark, and the proposed weighting has not shown a reliable advantage in these tests.

## The analysis in everyday language

1. **Prepare the data.** `First.py` reads price and volume data, calculates technical indicators and five-day-ahead returns, and saves the prepared table.
2. **Find market states.** An HMM groups dates into four states. For forecasting, it is fitted on the training dates only. The held-out dates are assigned with forward filtering, which uses information available up to that date.
3. **Split by time.** Earlier dates train the models, a later block selects settings, and the final dates evaluate forecasts. The last five dates before a boundary are removed because five-day outcomes would otherwise overlap the next period.
4. **Tune each model fairly.** Bayesian and linear model penalties are selected on the same chronological validation block. Adaptive LASSO uses training-only cross-validation for its first-stage feature weights, then the shared validation block to choose its final penalty. The final test block is never used to choose settings.
5. **Compare models.** The study includes pooled models, models fitted separately by regime, the full proposed prior, versions with one adaptive component removed, and a simple historical-average forecast.
6. **Use a realistic simple benchmark.** For each forecast date, average only target returns whose five-day outcomes would already have finished by that date. The expanding-mean $R^2$ compares the model to that changing historical average.
7. **Check feature recovery in simulations.** The pooled interaction script gives one pooled model separate feature slopes for each known simulated regime, tunes the penalty using training-only cross-validation, and reports whether it recovers the truly active features.
8. **Measure uncertainty in comparisons.** Daily forecast errors are compared with Diebold--Mariano tests using a four-lag HAC variance. Rolling-window differences are summarized with paired annual block bootstraps; the revised comparison has only four annual blocks, so those intervals are exploratory.

## Important code files

| File | What it does |
| --- | --- |
| `First.py` | Builds the features, five-day target, and descriptive full-history regime labels. |
| `tune_bayesian_lambda0.py` | Chooses the shared Bayesian shrinkage scale and full-prior settings using validation data. |
| `robust_real_data_validation.py` | Runs the main chronological comparison, including pooled and regime-specific baselines and ablations. |
| `rolling_window_validation.py` | Repeats the comparison over 11 annual test windows (2015--2025), each tuned on the immediately preceding year. |
| `second_market_validation.py` | Repeats the fixed-split comparison on sector ETFs. |
| `simulation_study.py` | Defines the data-generating mechanisms and fits all models for one simulation setting. |
| `repeated_simulation_study.py` | Repeats each simulation setting with new random seeds and saves averages and variability. |
| `pooled_regime_interaction_simulation.py` | Adds a fair pooled LASSO comparator with separate feature slopes for each simulated regime; reports forecast error and feature recovery. |
| `forecast_comparison_tests.py` | Calculates paired daily forecast-error tests from saved predictions. |
| `rolling_block_bootstrap.py` | Calculates paired bootstrap intervals for annual rolling-window errors. |
| `bayesian_lasso_experiment.py` | Contains the Gibbs sampler and the simple Bayesian-LASSO diagnostics experiment. |
| `multi_chain_mcmc_diagnostics.py` | Runs four independent sampler chains and summarizes their mixing diagnostics. |

## A small example of the central calculation

The following is the weight formula used by the proposed model. The variable names are intentionally descriptive:

```python
from math import exp


def make_shrinkage_weight(base_strength, regime_uncertainty,
                          feature_evidence, gamma, delta, epsilon):
    """Return the penalty for one feature in one market regime."""
    uncertainty_multiplier = exp(gamma * regime_uncertainty)
    evidence_divisor = (feature_evidence + epsilon) ** delta
    return base_strength * uncertainty_multiplier / evidence_divisor
```

Read it from the inside out:

- `base_strength` is the common starting penalty, called `lambda0` in the paper.
- `regime_uncertainty` increases the penalty when `gamma` is positive.
- `feature_evidence` reduces the penalty when `delta` is positive.
- `epsilon` prevents division by zero when the evidence score is zero.
- Both evidence and regime diagnostics must be calculated from the training data only.

The real-data tuning code now checks 11 geometrically spaced `lambda0` values from 100 to 10,000. It selected `lambda0 = 1000`, `gamma = 0`, `delta = 0.05`, and `epsilon = 0.001`. Since `gamma = 0`, the uncertainty multiplier is exactly one. The evidence exponent is small, so the feature evidence changes the penalties only modestly. This setting should not be described as strong evidence for the full feature-regime mechanism.

## How to run the work

Run commands from the project folder so that the relative `data/` paths resolve correctly. Install the packages listed in `important_code/requirements.txt` in a dedicated Python environment before running the scripts.

```powershell
python important_code/First.py
python important_code/tune_bayesian_lambda0.py
python important_code/robust_real_data_validation.py
python important_code/forecast_comparison_tests.py
python important_code/rolling_window_validation.py
python important_code/rolling_block_bootstrap.py
python important_code/second_market_validation.py
python important_code/repeated_simulation_study.py
python important_code/pooled_regime_interaction_simulation.py
```

The repeated simulation is the most computationally expensive step. The primary real-data script also writes `data/robust_real_data_validation/linear_baseline_validation_tuning.csv`; this file records the tested penalties and validation RMSEs for the linear baselines. Each main script prints the output files it creates. Keep the saved configuration, predictions, and results together with the exact code version used to produce the manuscript tables.

## How to read the results

- **RMSE and MAE:** smaller values mean smaller average forecast errors.
- **Expanding historical-mean out-of-sample $R^2$:** positive values beat a moving average of target outcomes that had finished by each forecast date; negative values lose to that simple benchmark.
- **Direction accuracy:** the share of dates on which the forecast gets the sign right. Compare it with the always-up rate, not with 50% alone.
- **Feature selection:** a coefficient threshold gives a descriptive list, not formal proof that a variable matters.
- **Diebold--Mariano p-value:** tests whether two models have different average forecast losses. It does not measure trading profit.
- **Ablation:** removes one part of the proposed formula to check whether that part adds value.
- **Oracle:** uses the true simulated coefficients. It is only a lower-error reference and is not an available forecasting model in real data.

## Reproducibility and submission status

The price data are sourced from Yahoo Finance and are not included as a redistribution package. The analysis code and result files are present locally, but a public repository with a persistent DOI has not been created. The real-data evaluations include firms that are large and actively traded today, so survivorship bias remains. The rolling test now covers 2015--2025 and tunes settings on the preceding year for each annual test window. The selected weighting turns uncertainty weighting off, and the rolling bootstrap uses four annual blocks only. Create and verify that archive before journal submission. The current stock universe contains firms that are large and traded today, so survivorship bias remains a limitation. Confirm author order, affiliation, and supervisor approval before submission.
