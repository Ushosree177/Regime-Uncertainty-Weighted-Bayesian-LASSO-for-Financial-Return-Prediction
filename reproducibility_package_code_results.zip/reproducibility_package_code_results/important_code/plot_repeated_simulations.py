"""Plot every model in the repeated simulation study.

Run this from the project folder with:
    python important_code/plot_repeated_simulations.py

The input is the CSV produced by repeated_simulation_study.py. Each small
panel shows one sample-size and scenario combination. Bars are mean RMSE, and
thin error bars show one standard deviation across the 30 replications.
"""
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd

# Keep file locations relative to the project folder so the script is easy to move.
DATA_FILE = Path("data/repeated_simulation_study/average_model_metrics.csv")
OUTPUT_FILE = Path("paper_materials/springer_submission/figures/simulation_rmse_comparison.png")


def main():
    """Read the summary table and draw six small comparisons."""
    results = pd.read_csv(DATA_FILE)
    scenarios = [
        ("Strong", 5000), ("Strong", 10000),
        ("Weak", 5000), ("Weak", 10000),
        ("SmallNoisy", 200), ("SmallNoisy", 500),
    ]

    figure, axes = plt.subplots(2, 3, figsize=(15, 9), sharey=False)
    for axis, (scenario, sample_count) in zip(axes.flat, scenarios):
        # Get one row per model for this scenario and order models by their error.
        panel = results[
            (results["Case"] == scenario)
            & (results["Samples_Per_Regime"] == sample_count)
        ].sort_values("RMSE_Mean")

        axis.bar(
            panel["Model"], panel["RMSE_Mean"],
            yerr=panel["RMSE_Std"], capsize=2, color="#3973ac",
        )
        title = scenario.replace("SmallNoisy", "Small, noisy")
        axis.set_title(f"{title}: {sample_count:,} samples per regime")
        axis.set_ylabel("Mean test RMSE (error bar: 1 SD)")
        axis.tick_params(axis="x", labelrotation=70, labelsize=7)
        axis.grid(axis="y", alpha=0.25)

    figure.suptitle("All models in the repeated simulation study", fontsize=15)
    figure.tight_layout()
    OUTPUT_FILE.parent.mkdir(parents=True, exist_ok=True)
    figure.savefig(OUTPUT_FILE, dpi=220, bbox_inches="tight")
    plt.close(figure)
    print(f"Saved simulation comparison plot to {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
