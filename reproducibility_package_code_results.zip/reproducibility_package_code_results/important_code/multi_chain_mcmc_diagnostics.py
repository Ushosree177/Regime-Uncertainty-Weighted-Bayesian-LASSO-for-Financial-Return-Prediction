"""
Multi-chain MCMC diagnostics for the Bayesian LASSO experiment.

This script does not change the predictive validation tables. It reruns the
Bayesian LASSO samplers with multiple random seeds on the same training split
used in bayesian_lasso_experiment.py and summarizes cross-chain convergence
diagnostics for the retained posterior draws.
"""

from pathlib import Path
from statistics import NormalDist

import numpy as np
import pandas as pd

from bayesian_lasso_experiment import (
    BURN_IN,
    FEATURE_COLUMNS,
    INPUT_FILE,
    LAMBDA_0,
    MCMC_ITERATIONS,
    MAX_GLOBAL_TRAIN_ROWS,
    MAX_REGIME_TRAIN_ROWS,
    REGIME_ORDER,
    RANDOM_STATE,
    THIN,
    BayesianLassoGibbs,
    add_research_features,
    load_data,
    make_time_split,
    prepare_model_data,
    sample_rows,
    scale_train_and_test,
)


OUTPUT_DIR = Path("data") / "bayesian_lasso"
OUTPUT_FILE = OUTPUT_DIR / "multi_chain_mcmc_diagnostics.csv"
N_CHAINS = 4
CHAIN_SEEDS = [42, 142, 242, 342]
STANDARD_NORMAL = NormalDist()


def fit_chains(x_train, y_train, lambda_value=LAMBDA_0):
    """Fit independent chains and return retained beta and sigma draws."""
    beta_chains = []
    sigma_chains = []

    for seed in CHAIN_SEEDS:
        rng = np.random.default_rng(seed)
        n_features = x_train.shape[1]
        initial_beta = rng.normal(loc=0.0, scale=0.2, size=n_features)
        initial_tau_squared = rng.lognormal(mean=0.0, sigma=0.5, size=n_features)
        initial_sigma_squared = float(rng.lognormal(mean=0.0, sigma=0.5))
        model = BayesianLassoGibbs(
            lambda_value=lambda_value,
            n_iterations=MCMC_ITERATIONS,
            burn_in=BURN_IN,
            thin=THIN,
            random_state=seed,
            initial_beta=initial_beta,
            initial_tau_squared=initial_tau_squared,
            initial_sigma_squared=initial_sigma_squared,
        )
        model.fit(x_train, y_train)
        beta_chains.append(model.beta_samples_)
        sigma_chains.append(model.sigma_squared_samples_)

    return np.array(beta_chains), np.array(sigma_chains)


def gelman_rubin_rhat(draws):
    """
    Compute classic Gelman-Rubin R-hat for an array shaped chains x draws x ...
    """
    draws = np.asarray(draws, dtype=float)
    if draws.ndim == 2:
        draws = draws[:, :, None]

    n_chains, n_draws = draws.shape[:2]
    flattened = draws.reshape(n_chains, n_draws, -1)

    chain_means = flattened.mean(axis=1)
    chain_vars = flattened.var(axis=1, ddof=1)
    within = chain_vars.mean(axis=0)
    between = n_draws * chain_means.var(axis=0, ddof=1)
    variance_hat = ((n_draws - 1) / n_draws) * within + between / n_draws

    rhat = np.ones_like(variance_hat)
    valid = within > 1e-12
    rhat[valid] = np.sqrt(variance_hat[valid] / within[valid])
    rhat[~np.isfinite(rhat)] = np.nan
    return rhat


def average_ranks(values):
    """Return one-based average ranks for ties without requiring SciPy."""
    values = np.asarray(values, dtype=float)
    order = np.argsort(values, kind="mergesort")
    sorted_values = values[order]
    ranks = np.empty(len(values), dtype=float)

    start = 0
    while start < len(values):
        end = start + 1
        while end < len(values) and sorted_values[end] == sorted_values[start]:
            end += 1
        average_rank = (start + 1 + end) / 2.0
        ranks[order[start:end]] = average_rank
        start = end

    return ranks


def rank_normalize(draws):
    """Rank-normalize draws using Blom's offset."""
    flat = np.asarray(draws, dtype=float).reshape(-1)
    ranks = average_ranks(flat)
    denominator = len(flat) + 0.25
    probabilities = (ranks - 0.375) / denominator
    probabilities = np.clip(probabilities, 1e-12, 1 - 1e-12)
    normalized = np.array([STANDARD_NORMAL.inv_cdf(p) for p in probabilities])
    return normalized.reshape(np.asarray(draws).shape)


def split_chains(draws):
    """Split each chain in half for split-R-hat diagnostics."""
    draws = np.asarray(draws, dtype=float)
    if draws.ndim == 2:
        draws = draws[:, :, None]

    n_chains, n_draws = draws.shape[:2]
    half_draws = n_draws // 2
    trimmed = draws[:, : 2 * half_draws, :]
    first_half = trimmed[:, :half_draws, :]
    second_half = trimmed[:, half_draws:, :]
    return np.concatenate([first_half, second_half], axis=0)


def split_rhat(draws):
    """Compute split R-hat after the chains have already been transformed."""
    return gelman_rubin_rhat(split_chains(draws))


def rank_normalized_split_rhat(draws):
    """Compute rank-normalized split R-hat for arrays shaped chains x draws x ..."""
    draws = np.asarray(draws, dtype=float)
    if draws.ndim == 2:
        draws = draws[:, :, None]

    n_params = draws.shape[2]
    rhat_values = np.empty(n_params)
    for param_index in range(n_params):
        transformed = rank_normalize(draws[:, :, param_index])
        rhat_values[param_index] = split_rhat(transformed)[0]
    return np.maximum(rhat_values, 1.0)


def folded_rank_normalized_split_rhat(draws):
    """Compute folded rank-normalized split R-hat for tail-scale sensitivity."""
    draws = np.asarray(draws, dtype=float)
    if draws.ndim == 2:
        draws = draws[:, :, None]

    folded = np.abs(draws - np.median(draws, axis=(0, 1), keepdims=True))
    return rank_normalized_split_rhat(folded)


def pooled_ess_proxy(draws):
    """
    Conservative multi-chain ESS proxy based on each chain's single-chain ESS.

    The existing sampler already implements a positive-autocorrelation ESS.
    Summing that estimate across chains gives an auditable lower-level summary
    without adding another dependency such as ArviZ.
    """
    draws = np.asarray(draws, dtype=float)
    if draws.ndim == 2:
        draws = draws[:, :, None]

    n_chains, _, n_params = draws.shape
    ess = np.empty(n_params)
    for param_index in range(n_params):
        chain_ess = [
            BayesianLassoGibbs._effective_sample_size(draws[chain, :, param_index])
            for chain in range(n_chains)
        ]
        ess[param_index] = np.sum(chain_ess)
    return ess


def summarize_chains(model_name, regime, rows_used, beta_chains, sigma_chains):
    """Create one diagnostic summary row for a fitted multi-chain model."""
    beta_rank_split_rhat = rank_normalized_split_rhat(beta_chains)
    beta_folded_rank_split_rhat = folded_rank_normalized_split_rhat(beta_chains)
    sigma_rank_split_rhat = rank_normalized_split_rhat(sigma_chains)
    sigma_folded_rank_split_rhat = folded_rank_normalized_split_rhat(sigma_chains)
    beta_ess = pooled_ess_proxy(beta_chains)
    sigma_ess = pooled_ess_proxy(sigma_chains)

    return {
        "Model": model_name,
        "Regime": regime,
        "Lambda0": LAMBDA_0,
        "Rows_Used": rows_used,
        "Chains": N_CHAINS,
        "Iterations": MCMC_ITERATIONS,
        "Burn_In": BURN_IN,
        "Thin": THIN,
        "Saved_Draws_Per_Chain": beta_chains.shape[1],
        "Max_Beta_Rank_Split_Rhat": float(np.nanmax(beta_rank_split_rhat)),
        "Max_Beta_Folded_Rank_Split_Rhat": float(np.nanmax(beta_folded_rank_split_rhat)),
        "Min_Beta_ESS_Proxy": float(np.nanmin(beta_ess)),
        "Median_Beta_ESS_Proxy": float(np.nanmedian(beta_ess)),
        "Sigma_Squared_Rank_Split_Rhat": float(sigma_rank_split_rhat[0]),
        "Sigma_Squared_Folded_Rank_Split_Rhat": float(sigma_folded_rank_split_rhat[0]),
        "Sigma_Squared_ESS_Proxy": float(sigma_ess[0]),
    }


def main():
    print("MULTI-CHAIN MCMC DIAGNOSTICS")
    print(f"Input file: {INPUT_FILE}")
    print(f"Chains: {N_CHAINS}")
    print(f"Baseline shrinkage lambda0: {LAMBDA_0:g}")
    print(f"Chain seeds: {CHAIN_SEEDS}")
    print("Each chain uses a different random seed and dispersed random initial beta, tau, and sigma states.")

    raw_data = load_data()
    data_with_target = add_research_features(raw_data)
    model_data = prepare_model_data(data_with_target)
    train_data, test_data, split_date = make_time_split(model_data)

    print(f"Train/test split date: {pd.Timestamp(split_date).date()}")
    print(f"Training rows before caps: {len(train_data)}")
    print(f"Features: {len(FEATURE_COLUMNS)}")

    rows = []

    print("\nStandard Bayesian LASSO")
    standard_train = sample_rows(train_data, MAX_GLOBAL_TRAIN_ROWS)
    x_train, _, y_train, _, _, _ = scale_train_and_test(standard_train, test_data)
    beta_chains, sigma_chains = fit_chains(x_train, y_train)
    rows.append(
        summarize_chains(
            "Standard Bayesian LASSO",
            "All",
            len(standard_train),
            beta_chains,
            sigma_chains,
        )
    )

    for regime in REGIME_ORDER:
        print(f"\nRegime Bayesian LASSO - {regime}")
        regime_train = train_data[train_data["Regime"] == regime].copy()
        regime_test = test_data[test_data["Regime"] == regime].copy()
        if regime_train.empty or regime_test.empty:
            print("Skipping because train or test split is empty.")
            continue

        regime_train = sample_rows(regime_train, MAX_REGIME_TRAIN_ROWS)
        x_train, _, y_train, _, _, _ = scale_train_and_test(regime_train, regime_test)
        beta_chains, sigma_chains = fit_chains(x_train, y_train)
        rows.append(
            summarize_chains(
                f"Regime Bayesian LASSO - {regime}",
                regime,
                len(regime_train),
                beta_chains,
                sigma_chains,
            )
        )

    diagnostics = pd.DataFrame(rows)
    OUTPUT_DIR.mkdir(exist_ok=True)
    diagnostics.to_csv(OUTPUT_FILE, index=False)

    print("\nMULTI-CHAIN SUMMARY")
    print(diagnostics.round(6).to_string(index=False))
    print(f"\nSaved: {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
