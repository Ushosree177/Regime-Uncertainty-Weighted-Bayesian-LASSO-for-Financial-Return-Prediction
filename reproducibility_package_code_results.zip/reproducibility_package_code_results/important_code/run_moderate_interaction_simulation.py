"""Run the missing moderate-design repetitions for the interaction baseline.

In plain language: each repeat creates one fresh simulated dataset, fits the
pooled LASSO that has a separate feature block for each known regime, and
scores its predictions on the held-out 25 percent. Training-only five-fold
cross-validation chooses the LASSO penalty. Results are saved as one row per
repeat plus a compact average table used in the manuscript.
"""
from pathlib import Path
import pandas as pd
from pooled_regime_interaction_simulation import fit_one_replication
from repeated_simulation_study import N_REPLICATIONS, SCENARIOS

# Find the moderate design in the shared scenario list. Its position is used
# in the common random-seed rule so these results pair with the main study.
CASE, SAMPLES_PER_REGIME = "Moderate", 750
SCENARIO_NUMBER = next(
    number for number, setting in enumerate(SCENARIOS)
    if setting == (CASE, SAMPLES_PER_REGIME)
)
REPETITIONS = N_REPLICATIONS

rows = []
for repetition in range(1, REPETITIONS + 1):
    # fit_one_replication reuses the same seed rule as the other scenarios,
    # which makes these results directly comparable with the main simulation.
    rows.append(fit_one_replication(
        CASE, SAMPLES_PER_REGIME, repetition, SCENARIO_NUMBER
    ))
    print(f"Completed moderate replication {repetition}/{REPETITIONS}", flush=True)

replicates = pd.DataFrame(rows)
summary = pd.DataFrame([{
    "Case": CASE,
    "Samples_Per_Regime": SAMPLES_PER_REGIME,
    "Model": replicates["Model"].iloc[0],
    "RMSE_Mean": replicates["RMSE"].mean(),
    "RMSE_Std": replicates["RMSE"].std(),
    "MAE_Mean": replicates["MAE"].mean(),
    "R2_Mean": replicates["R2"].mean(),
    "Direction_Accuracy_Mean": replicates["Direction_Accuracy"].mean(),
    "Alpha_Mean": replicates["Alpha"].mean(),
    "Recovery_Precision_Mean": replicates["Recovery_Precision"].mean(),
    "Recovery_Recall_Mean": replicates["Recovery_Recall"].mean(),
    "Recovery_F1_Mean": replicates["Recovery_F1"].mean(),
    "Selected_Count_Mean": replicates["Recovery_Selected_Count"].mean(),
}])

# Save raw repeats for reproducibility and a one-row table for manuscript edits.
output = Path("data/pooled_regime_interaction_simulation")
output.mkdir(parents=True, exist_ok=True)
replicates.to_csv(output / "moderate_replication_results.csv", index=False)
summary.to_csv(output / "moderate_summary.csv", index=False)
print(summary.round(6).to_string(index=False))
