"""A small, readable demonstration of a fair model comparison.

Problem this example explains
-----------------------------
Suppose the relationship between two inputs and an outcome changes by market
regime. A model trained on all regimes together has to use one relationship
everywhere. A regime-specific model can learn one relationship per regime.

If we compare a proposed regime-specific method only with pooled models, any
improvement could come from separating the regimes, not from the new prior.
The fair comparison therefore includes both pooled and regime-specific models.

Run from the project folder with:
    python important_code/baseline_fairness_demo.py

This is a teaching example, not a replacement for the paper's full simulation.
"""

import numpy as np
import pandas as pd
from sklearn.linear_model import Lasso
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import StandardScaler


def make_example_data(seed=7, rows_per_regime=800):
    """Create four groups whose input-to-outcome relationships differ."""
    rng = np.random.default_rng(seed)
    regime_names = ["Recovery", "Bull", "Bear", "Crisis"]
    # Each row lists the true effect of input 1 and input 2 in that regime.
    effects = {
        "Recovery": [2.0, 0.0],
        "Bull": [0.0, 2.0],
        "Bear": [-2.0, 0.0],
        "Crisis": [0.0, -2.0],
    }

    rows = []
    for regime in regime_names:
        inputs = rng.normal(size=(rows_per_regime, 2))
        noise = rng.normal(scale=0.7, size=rows_per_regime)
        outcome = inputs @ np.array(effects[regime]) + noise
        for x1, x2, y in zip(inputs[:, 0], inputs[:, 1], outcome):
            rows.append((regime, x1, x2, y))

    return pd.DataFrame(rows, columns=["regime", "input_1", "input_2", "outcome"])


def fit_lasso_and_predict(train_x, train_y, test_x):
    """Scale the inputs, fit a simple LASSO model, and predict outcomes."""
    scaler = StandardScaler()
    train_x_scaled = scaler.fit_transform(train_x)
    test_x_scaled = scaler.transform(test_x)

    model = Lasso(alpha=0.03, max_iter=10_000)
    model.fit(train_x_scaled, train_y)
    return model.predict(test_x_scaled)


def main():
    data = make_example_data()

    # Keep the first 70% of each regime for training and the rest for testing.
    train_parts = []
    test_parts = []
    for _, group in data.groupby("regime", sort=False):
        split_at = int(len(group) * 0.7)
        train_parts.append(group.iloc[:split_at])
        test_parts.append(group.iloc[split_at:])
    train = pd.concat(train_parts)
    test = pd.concat(test_parts)

    feature_names = ["input_1", "input_2"]
    results = []

    # Baseline 1: one model must explain every regime with the same coefficients.
    pooled_predictions = fit_lasso_and_predict(
        train[feature_names], train["outcome"], test[feature_names]
    )
    results.append(("Pooled LASSO", mean_squared_error(test["outcome"], pooled_predictions) ** 0.5))

    # Baseline 2: each regime gets its own model. This is the essential fair baseline.
    separate_predictions = pd.Series(index=test.index, dtype=float)
    for regime in data["regime"].unique():
        train_group = train[train["regime"] == regime]
        test_group = test[test["regime"] == regime]
        separate_predictions.loc[test_group.index] = fit_lasso_and_predict(
            train_group[feature_names], train_group["outcome"], test_group[feature_names]
        )
    results.append(("Regime-specific LASSO", mean_squared_error(test["outcome"], separate_predictions) ** 0.5))

    # Read the table as: smaller test RMSE means predictions were closer to truth.
    print("Test prediction error (RMSE; lower is better)")
    print(pd.DataFrame(results, columns=["Model", "Test RMSE"]).to_string(index=False))
    print("\nWhy it matters: compare a new regime-aware method with the second row too.")
    print("Otherwise, the apparent gain may come from handling regimes, not from the new prior.")


if __name__ == "__main__":
    main()
