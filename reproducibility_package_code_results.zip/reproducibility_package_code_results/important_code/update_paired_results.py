from pathlib import Path
p=Path('paper_materials/springer_submission/springer_manuscript.tex')
s=p.read_text(encoding='utf-8')
replacements=[
(r'''The proposed full prior does not improve on the matched regime-specific Bayesian baseline.''', r'''The small-noisy $n=500$ experiment shows a setting-specific feature-recovery benefit for the full prior, although its RMSE difference from regime-specific Bayesian LASSO is not statistically significant; the uncertainty component also worsens RMSE in the strong $n=10{,}000$ setting.'''),
(r'''The proposed feature weighting does not improve on the matched regime-specific Bayesian baseline.''', r'''The proposed weighting has one setting-specific feature-recovery benefit at $n=500$ in the small-noisy design, but its paired RMSE difference is not statistically significant; at strong $n=10{,}000$, the uncertainty component increases RMSE.'''),
(r'''The proposed full prior does not improve on regime-specific Bayesian LASSO. In the moderate partially overlapping design,''', r'''The full prior modestly improves feature-selection precision and F1 over regime-specific Bayesian LASSO at $n=500$ in the small-noisy design, while selecting fewer features; paired RMSE tests do not show a significant gain, and recall is lower. At strong $n=10{,}000$, adding the uncertainty term worsens RMSE relative to the evidence-only model. In the moderate partially overlapping design,'''),
(r'''The real-market experiments are the stricter practical tests. They do not establish an interpretation benefit or a forecasting improvement from the proposed weighting.''', r'''The real-market experiments are the stricter practical tests. The small-noisy feature-recovery result is specific to one simulation setting; real-market experiments do not establish an interpretation benefit or a forecasting improvement from the proposed weighting.'''),
(r'''The proposed full prior does not improve on the matched Bayesian baseline. In financial data,''', r'''The proposed full prior has a modest, setting-specific feature-recovery benefit at $n=500$ in the small-noisy simulation, but not a statistically significant RMSE gain; at strong $n=10{,}000$, the uncertainty term worsens RMSE. In financial data,'''),
]
for old,new in replacements:
 n=s.count(old)
 if n != 1: raise ValueError((old[:70],n))
 s=s.replace(old,new,1)
# Explicit detailed result text in the prediction-performance discussion.
old=r'''In the small, noisy settings, regime-specific LASSO remains the strongest fitted method. The oracle is included only as a reference.'''
new=r'''In the small, noisy settings, regime-specific LASSO remains the lowest-RMSE frequentist fit. At $n=500$, the full prior has RMSE 1.8437 versus 1.8467 for regime-specific Bayesian LASSO; the paired test does not establish an RMSE improvement ($p=0.371$, Holm-adjusted $p=0.371$). Its mean precision and F1 are higher (0.719 and 0.788 versus 0.540 and 0.682), and it selects fewer features (4.58 versus 6.78), at the cost of lower recall (0.933 versus 0.996). Table \ref{tab:paired_sim_tests} reports the paired uncertainty estimates. At strong $n=10{,}000$, the full prior has higher RMSE than the evidence-only model (1.2035 versus 1.2017), isolating a cost from the uncertainty term. The oracle is included only as a reference.'''
if s.count(old)!=1: raise ValueError(('prediction paragraph',s.count(old)))
s=s.replace(old,new,1)
# Add the full paired-test results after the simulation tables and before real-market results.
marker=r'''\section{Real-Market Evaluation}'''
if s.count(marker)!=1: raise ValueError(('real market section',s.count(marker)))
paired=r'''\subsection{Paired comparisons of simulation results}

For each contrast, we pair the two models' outcomes from the same simulation replication ($n=30$). Mean differences and their 95\% confidence intervals use the paired differences; two-sided Wilcoxon signed-rank tests assess whether the paired differences are centered at zero. Holm adjustment is applied across the six outcomes in Table \ref{tab:paired_sim_tests}. The positive feature-selection result at $n=500$ is accompanied by lower recall, so it is a sparsity--recall trade-off rather than a uniform recovery improvement. The RMSE confidence interval includes zero. In the strong $n=10{,}000$ design, the Bayesian tuning choice has $\delta=0$, so full versus evidence-only isolates the uncertainty multiplier.

\begin{table}[htbp]
\centering
\caption{Paired comparisons across 30 simulation replications. Differences are full model minus comparator; negative RMSE differences favor the full model. Confidence intervals are paired-$t$ 95\% intervals. Wilcoxon tests are two-sided; Holm $p$-values adjust the six tests shown.}
\label{tab:paired_sim_tests}
\footnotesize
\setlength{\tabcolsep}{3pt}
\begin{tabular*}{\textwidth}{@{\extracolsep{\fill}}p{3.0cm}lccc}
\toprule
Comparison & Outcome & Mean difference (95\% CI) & Raw $p$ & Holm $p$ \\
\midrule
Full vs regime Bayesian, small noisy $n=500$ & RMSE & $-0.003015$ ($-0.008279$, $0.002249$) & 0.371 & 0.371 \\
Full vs regime Bayesian, small noisy $n=500$ & Precision & $0.1788$ ($0.1515$, $0.2060$) & $1.73\times10^{-6}$ & $4.78\times10^{-6}$ \\
Full vs regime Bayesian, small noisy $n=500$ & Recall & $-0.0625$ ($-0.0731$, $-0.0519$) & $6.60\times10^{-7}$ & $2.64\times10^{-6}$ \\
Full vs regime Bayesian, small noisy $n=500$ & F1 & $0.1062$ ($0.0853$, $0.1271$) & $3.73\times10^{-9}$ & $2.24\times10^{-8}$ \\
Full vs regime Bayesian, small noisy $n=500$ & Selected count & $-2.20$ ($-2.46$, $-1.94$) & $1.59\times10^{-6}$ & $4.78\times10^{-6}$ \\
Full vs evidence-only, strong $n=10{,}000$ & RMSE & $0.001764$ ($0.001342$, $0.002185$) & $5.59\times10^{-9}$ & $2.79\times10^{-8}$ \\
\bottomrule
\end{tabular*}
\end{table}

'''
s=s.replace(marker,paired+marker,1)
p.write_text(s,encoding='utf-8')
print('Added paired simulation interpretation and results table.')
