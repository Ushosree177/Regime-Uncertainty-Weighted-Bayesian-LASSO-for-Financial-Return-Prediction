"""Build a compact public archive containing code and result tables only.

Run from the reproducibility-package folder:
    python important_code/build_public_archive.py

The output ZIP is written next to this folder. Market-price downloads, derived
market panels, and row-level financial forecasts are deliberately excluded;
the scripts can retrieve the inputs again when they are run.
"""

from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


PACKAGE = Path(__file__).resolve().parents[1]
OUTPUT = PACKAGE.parent / "reproducibility_package_code_results.zip"

# These files contain price-derived input or row-level market forecasts.
EXCLUDED_NAMES = {
    "fixed_split_predictions.csv",
    "rolling_predictions.csv",
    "rolling_window_predictions.csv",
    "sector_etf_predictions.csv",
    "sector_etf_raw_prices.csv",
    "sector_etf_indicators.csv",
    "sector_etf_market_regimes.csv",
    "sector_etf_final_dataset_with_regimes.csv",
}


def include_file(path):
    """Keep code, documentation, and aggregate results; skip excluded data."""
    if ".git" in path.parts or "__pycache__" in path.parts:
        return False
    if path.suffix in {".pyc", ".pyo"}:
        return False
    return path.name not in EXCLUDED_NAMES


def main():
    """Write the selected files to a compressed ZIP with relative paths."""
    files = sorted(path for path in PACKAGE.rglob("*") if path.is_file() and include_file(path))
    with ZipFile(OUTPUT, mode="w", compression=ZIP_DEFLATED, compresslevel=6) as archive:
        for path in files:
            archive.write(path, path.relative_to(PACKAGE))

    print(f"Included {len(files)} files")
    print(f"Created {OUTPUT}")
    print(f"Archive size: {OUTPUT.stat().st_size / (1024 * 1024):.1f} MiB")


if __name__ == "__main__":
    main()
