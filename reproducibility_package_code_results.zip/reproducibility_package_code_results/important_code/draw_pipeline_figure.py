"""Draw the manuscript's readable, high-resolution analysis-flow diagram."""

from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch


OUTPUT_FILE = Path("paper_materials/springer_submission/figures/pipeline_diagram.png")


def add_box(axis, x, y, width, height, heading, detail):
    """Draw one numbered step with a short title and a plain-language note."""
    box = FancyBboxPatch(
        (x, y), width, height,
        boxstyle="round,pad=0.03,rounding_size=0.12",
        facecolor="#F2F6FB", edgecolor="#263B55", linewidth=1.7,
    )
    axis.add_patch(box)
    axis.text(x + width / 2, y + height * 0.69, heading,
              ha="center", va="center", fontsize=17, weight="bold",
              color="#17324D", wrap=True)
    axis.text(x + width / 2, y + height * 0.27, detail,
              ha="center", va="center", fontsize=15, color="#253746",
              wrap=True)


def add_arrow(axis, start, end):
    """Connect two boxes with one easy-to-follow arrow."""
    axis.add_patch(FancyArrowPatch(
        start, end, arrowstyle="-|>", mutation_scale=18,
        linewidth=1.8, color="#46627F",
    ))


def main():
    """Create a two-row flow chart sized for print readability."""
    figure, axis = plt.subplots(figsize=(16, 8), dpi=300)
    axis.set_xlim(0, 16)
    axis.set_ylim(0, 8)
    axis.axis("off")

    width, height = 2.65, 1.55
    left_positions = [0.45, 3.55, 6.65, 9.75, 12.85]
    top_y, bottom_y = 5.1, 1.0

    top_steps = [
        ("1. Market\ndata", "Prices and\nvolume"),
        ("2. Forecast\ntarget", "Indicators and\nfive-day return"),
        ("3. Time\nsplit", "Train, validate, test;\npurge five dates"),
        ("4. Fit the\nHMM", "Training-period\nmarket data only"),
        ("5. Filter\nregimes", "Assign using\npast data"),
    ]
    for x, (heading, detail) in zip(left_positions, top_steps):
        add_box(axis, x, top_y, width, height, heading, detail)
    for index in range(4):
        add_arrow(axis,
                  (left_positions[index] + width + 0.03, top_y + height / 2),
                  (left_positions[index + 1] - 0.03, top_y + height / 2))

    # The bottom row runs from right to left, continuing the same timeline.
    bottom_steps = [
        ("9. Forecast\nand compare", "Test scores;\npaired comparisons"),
        ("8. Fit fair\nbaselines", "Global and\nseparate models"),
        ("7. Set\nshrinkage", "Feature weight\nwithin each state"),
        ("6. Training\nevidence", "Risk and evidence\nfrom training data"),
    ]
    bottom_positions = [1.1, 4.75, 8.4, 12.05]
    for x, (heading, detail) in zip(bottom_positions, bottom_steps):
        add_box(axis, x, bottom_y, width, height, heading, detail)

    # Connect the top-row regime output down to training-only score construction.
    add_arrow(axis, (left_positions[-1] + width / 2, top_y - 0.05),
              (bottom_positions[-1] + width / 2, bottom_y + height + 0.05))
    # Continue from right to left through a clear lane above the lower boxes.
    arrow_lane_y = bottom_y + height + 0.75
    for index in range(3, 0, -1):
        right_center = bottom_positions[index] + width / 2
        left_center = bottom_positions[index - 1] + width / 2
        axis.plot([right_center, right_center],
                  [bottom_y + height, arrow_lane_y], color="#46627F", linewidth=1.5)
        axis.plot([left_center, left_center],
                  [bottom_y + height, arrow_lane_y], color="#46627F", linewidth=1.5)
        add_arrow(axis, (right_center, arrow_lane_y), (left_center, arrow_lane_y))

    axis.text(8, 7.45, "Leakage-controlled forecasting workflow",
              ha="center", va="center", fontsize=21, weight="bold",
              color="#17324D")
    axis.text(8, 0.35,
              "Every learned quantity is fit on training dates; the final test block is used only for evaluation.",
              ha="center", va="center", fontsize=13, color="#253746")

    OUTPUT_FILE.parent.mkdir(parents=True, exist_ok=True)
    figure.savefig(OUTPUT_FILE, bbox_inches="tight", facecolor="white")
    plt.close(figure)
    print(f"Saved readable workflow figure to {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
