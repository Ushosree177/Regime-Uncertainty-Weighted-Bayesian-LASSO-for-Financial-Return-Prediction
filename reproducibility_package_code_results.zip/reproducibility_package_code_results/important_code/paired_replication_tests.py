"""Paired RMSE tests for the full prior in every simulation design.

Each comparison pairs models from the same replication, then applies one
Holm correction across all seven design-level tests. Run from the project root:

    python important_code/paired_replication_tests.py
"""
from pathlib import Path

import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests


DATA = Path("data/repeated_simulation_study")
METRICS = pd.read_csv(DATA / "replication_level_model_metrics.csv")
FULL = "Proposed Prior - Full"
REGIME_BAYES = "Regime-specific Bayesian LASSO"
DESIGNS = [
    ("Weak", 5000),
    ("Weak", 10000),
    ("Strong", 5000),
    ("Strong", 10000),
    ("SmallNoisy", 200),
    ("SmallNoisy", 500),
    ("Moderate", 750),
]


def compare_one_design(case, samples_per_regime):
    """Compare paired RMSE values for one design and return summary stats."""
    paired = {}
    for model in (FULL, REGIME_BAYES):
        rows = METRICS.loc[
            (METRICS["Case"] == case)
            & (METRICS["Samples_Per_Regime"] == samples_per_regime)
            & (METRICS["Model"] == model)
        ].sort_values("Replication")
        if len(rows) != 30:
            raise ValueError(f"Expected 30 rows for {case}, {samples_per_regime}, {model}")
        paired[model] = rows

    full_rows = paired[FULL]
    regime_rows = paired[REGIME_BAYES]
    if not (full_rows["Replication"].to_numpy() == regime_rows["Replication"].to_numpy()).all():
        raise ValueError(f"Replication IDs do not match for {case}, {samples_per_regime}")

    differences = full_rows["RMSE"].to_numpy() - regime_rows["RMSE"].to_numpy()
    if (differences == 0).all():
        # Exact ties have a zero-width interval and no evidence against the
        # null; define their two-sided signed-rank p-value as one.
        interval = (0.0, 0.0)
        p_value = 1.0
    else:
        interval = stats.t.interval(
            0.95,
            len(differences) - 1,
            loc=differences.mean(),
            scale=stats.sem(differences),
        )
        p_value = stats.wilcoxon(differences, alternative="two-sided").pvalue
    return {
        "Setting": case,
        "Samples_Per_Regime": samples_per_regime,
        "Replications": len(differences),
        "Mean_RMSE_Difference_Full_Minus_Regime_Bayes": differences.mean(),
        "CI95_Lower": interval[0],
        "CI95_Upper": interval[1],
        "Wilcoxon_P_Raw": p_value,
    }


def main():
    results = pd.DataFrame(
        [compare_one_design(case, n) for case, n in DESIGNS]
    )
    # One family contains the seven full-versus-regime-Bayesian RMSE
    # comparisons, one for every simulated design.
    results["Wilcoxon_P_Holm_7_Designs"] = multipletests(
        results["Wilcoxon_P_Raw"], method="holm"
    )[1]
    output = DATA / "paired_contrast_tests.csv"
    results.to_csv(output, index=False)
    print(results.round(7).to_string(index=False))
    print(f"\nSaved paired-test results to {output}")


if __name__ == "__main__":
    main()
