"""
Robust validation step 1: stronger real-data baselines and ablation study.

Why this script exists:

A reviewer may ask whether the proposed prior is better than obvious
alternatives, and whether both parts of the prior are actually needed.

This script compares:

1. Classical LASSO
2. Elastic Net
3. Adaptive LASSO
4. Regime-specific LASSO
5. Standard Bayesian LASSO
6. Regime-specific Bayesian LASSO
7. Proposed prior: uncertainty only
8. Proposed prior: evidence only
9. Proposed prior: uncertainty + evidence

The ablation logic is:

    Full prior:
        lambda_jr = exp(gamma * U_r) / (I_jr + epsilon)^delta

    Uncertainty only:
        lambda_jr = exp(gamma * U_r)

    Evidence only:
        lambda_jr = 1 / (I_jr + epsilon)^delta

This is still intentionally simple and explainable.
"""

from pathlib import Path
import json

import numpy as np
import pandas as pd
from scipy.special import logsumexp
from sklearn.linear_model import (
    ElasticNet, ElasticNetCV, Lasso, LassoCV, enet_path, lasso_path,
)
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler

from bayesian_lasso_experiment import BayesianLassoGibbs
from simulation_study import WeightedBayesianLassoGibbs


DATA_DIR = Path("data")
INPUT_FILE = DATA_DIR / "final_dataset_with_regimes.csv"
OUTPUT_DIR = DATA_DIR / "robust_real_data_validation"

TARGET_COLUMN = "Future_5_Day_Return"
MARKET_TICKER = "SPY"
RANDOM_STATE = 42
TARGET_HORIZON_DAYS = 5

REGIME_ORDER = ["Recovery", "Bull", "Bear", "Crisis"]

GAMMA = 1.0
DELTA = 0.1
EPSILON = 0.001
LAMBDA_0 = 1.0  # replaced by the validation calibration file when available
PREDICTION_ROWS = []
LINEAR_TUNING = {}
TRAINING_MEAN_FORECASTS = {}

MAX_GLOBAL_TRAIN_ROWS = None  # Use every eligible training row.
MAX_REGIME_TRAIN_ROWS = None  # Use every eligible row in each regime.

MCMC_ITERATIONS = 700
BURN_IN = 300
THIN = 5

FEATURE_COLUMNS = [
    "Daily_Return",
    "Log_Return",
    "Momentum_10",
    "ROC_10",
    "RSI_14",
    "MACD",
    "MACD_Signal",
    "MACD_Histogram",
    "Close_to_SMA_10",
    "Close_to_SMA_20",
    "Close_to_SMA_50",
    "Close_to_EMA_10",
    "Close_to_EMA_20",
    "Close_to_EMA_50",
    "ATR_14",
    "Normalized_ATR",
    "Volatility_20",
    "Bollinger_Width",
    "Bollinger_Position",
    "Volume_Ratio",
    "OBV_Change",
]

HMM_COLUMNS = ["Daily_Return", "Volatility_20", "Volume_Ratio"]


def load_data():
    """Load the final market dataset."""
    df = pd.read_csv(INPUT_FILE)
    df["Date"] = pd.to_datetime(df["Date"])
    df = df.sort_values(["Ticker", "Date"]).reset_index(drop=True)
    return df


def add_research_features(df):
    """Create the same target and relative indicators used earlier."""
    result = df.copy()

    result["Future_Close_5"] = result.groupby("Ticker")["Close"].shift(-5)
    result[TARGET_COLUMN] = (result["Future_Close_5"] / result["Close"]) - 1

    result["Normalized_ATR"] = result["ATR_14"] / result["Close"]

    result["Close_to_SMA_10"] = (result["Close"] / result["SMA_10"]) - 1
    result["Close_to_SMA_20"] = (result["Close"] / result["SMA_20"]) - 1
    result["Close_to_SMA_50"] = (result["Close"] / result["SMA_50"]) - 1

    result["Close_to_EMA_10"] = (result["Close"] / result["EMA_10"]) - 1
    result["Close_to_EMA_20"] = (result["Close"] / result["EMA_20"]) - 1
    result["Close_to_EMA_50"] = (result["Close"] / result["EMA_50"]) - 1

    result["OBV_Change"] = result.groupby("Ticker")["OBV"].pct_change()
    result["OBV_Change"] = result["OBV_Change"].replace([np.inf, -np.inf], np.nan)

    return result


def prepare_model_data(df):
    """Keep complete rows for modelling."""
    columns = ["Date", "Ticker", "Regime", TARGET_COLUMN] + FEATURE_COLUMNS
    model_data = df[columns].copy()
    model_data = model_data.replace([np.inf, -np.inf], np.nan)
    model_data = model_data.dropna(subset=[TARGET_COLUMN] + FEATURE_COLUMNS)
    model_data = model_data.sort_values("Date").reset_index(drop=True)
    return model_data


def name_regimes_from_training_market(market):
    """Map HMM state numbers to economic regime names using training data."""
    summary = (
        market.groupby("Regime_Number")
        .agg(
            Average_Return=("Daily_Return", "mean"),
            Average_Volatility=("Volatility_20", "mean"),
        )
        .reset_index()
    )

    names = {}
    crisis_row = summary.sort_values(
        ["Average_Volatility", "Average_Return"],
        ascending=[False, True],
    ).iloc[0]
    crisis_state = int(crisis_row["Regime_Number"])
    names[crisis_state] = "Crisis"

    remaining = summary[summary["Regime_Number"] != crisis_state].copy()
    bull_row = remaining.sort_values("Average_Return", ascending=False).iloc[0]
    bull_state = int(bull_row["Regime_Number"])
    names[bull_state] = "Bull"

    remaining = remaining[remaining["Regime_Number"] != bull_state].copy()
    bear_state = int(remaining.sort_values("Average_Return").iloc[0]["Regime_Number"])
    names[bear_state] = "Bear"

    for state in remaining["Regime_Number"]:
        if int(state) not in names:
            names[int(state)] = "Recovery"

    return names


def gaussian_log_likelihood(values, means, covariances):
    """Evaluate Gaussian HMM emission log likelihoods."""
    n_rows = values.shape[0]
    n_states = means.shape[0]
    n_features = values.shape[1]
    log_likelihood = np.empty((n_rows, n_states))

    for state in range(n_states):
        covariance = covariances[state] + np.eye(n_features) * 1e-8
        sign, log_det = np.linalg.slogdet(covariance)
        if sign <= 0:
            covariance = covariance + np.eye(n_features) * 1e-6
            sign, log_det = np.linalg.slogdet(covariance)

        inverse = np.linalg.inv(covariance)
        centered = values - means[state]
        quadratic = np.einsum("ij,jk,ik->i", centered, inverse, centered)
        log_likelihood[:, state] = -0.5 * (
            n_features * np.log(2 * np.pi) + log_det + quadratic
        )

    return log_likelihood


def forward_filter_probabilities(model, values, initial_log_alpha=None):
    """Compute past-information-only HMM filtering probabilities."""
    tiny = 1e-300
    log_likelihood = gaussian_log_likelihood(values, model.means_, model.covars_)
    log_transition = np.log(model.transmat_ + tiny)

    filtered = np.empty_like(log_likelihood)

    if initial_log_alpha is None:
        log_alpha = np.log(model.startprob_ + tiny) + log_likelihood[0]
    else:
        prediction_log_alpha = logsumexp(
            initial_log_alpha[:, None] + log_transition,
            axis=0,
        )
        log_alpha = prediction_log_alpha + log_likelihood[0]

    log_alpha = log_alpha - logsumexp(log_alpha)
    filtered[0] = np.exp(log_alpha)

    for row in range(1, len(values)):
        prediction_log_alpha = logsumexp(
            log_alpha[:, None] + log_transition,
            axis=0,
        )
        log_alpha = prediction_log_alpha + log_likelihood[row]
        log_alpha = log_alpha - logsumexp(log_alpha)
        filtered[row] = np.exp(log_alpha)

    return filtered, log_alpha


def relabel_split_with_train_hmm(train_data, test_data, number_of_regimes=4):
    """Fit the HMM on the training period and filter test regimes forward."""
    try:
        from hmmlearn.hmm import GaussianHMM
    except ImportError as error:
        message = "Please install hmmlearn for train-only regime validation."
        raise ImportError(message) from error

    train_market = (
        train_data[train_data["Ticker"] == MARKET_TICKER]
        .dropna(subset=HMM_COLUMNS)
        .sort_values("Date")
        .copy()
    )
    test_market = (
        test_data[test_data["Ticker"] == MARKET_TICKER]
        .dropna(subset=HMM_COLUMNS)
        .sort_values("Date")
        .copy()
    )

    scaler = StandardScaler()
    train_hmm_input = scaler.fit_transform(train_market[HMM_COLUMNS])
    test_hmm_input = scaler.transform(test_market[HMM_COLUMNS])

    model = GaussianHMM(
        n_components=number_of_regimes,
        covariance_type="full",
        n_iter=500,
        random_state=RANDOM_STATE,
    )
    model.fit(train_hmm_input)

    train_probabilities, last_train_log_alpha = forward_filter_probabilities(
        model,
        train_hmm_input,
    )
    test_probabilities, _ = forward_filter_probabilities(
        model,
        test_hmm_input,
        initial_log_alpha=last_train_log_alpha,
    )

    train_market["Regime_Number"] = train_probabilities.argmax(axis=1)
    test_market["Regime_Number"] = test_probabilities.argmax(axis=1)

    regime_names = name_regimes_from_training_market(train_market)
    train_market["Regime"] = train_market["Regime_Number"].map(regime_names)
    test_market["Regime"] = test_market["Regime_Number"].map(regime_names)
    train_market["Regime_Probability"] = train_probabilities.max(axis=1)
    test_market["Regime_Probability"] = test_probabilities.max(axis=1)

    regime_columns = ["Date", "Regime_Number", "Regime", "Regime_Probability"]

    relabeled_train = train_data.drop(columns=["Regime"], errors="ignore").merge(
        train_market[regime_columns],
        on="Date",
        how="inner",
    )
    relabeled_test = test_data.drop(columns=["Regime"], errors="ignore").merge(
        test_market[regime_columns],
        on="Date",
        how="inner",
    )

    return relabeled_train, relabeled_test


def split_train_validation_test(model_data, gap_days=TARGET_HORIZON_DAYS):
    """Make chronological splits with a five-date purge at each boundary.

    The outcome looks five trading days into the future. Removing the last five
    dates before validation and test keeps those outcomes from reaching across
    a split boundary.
    """
    unique_dates = np.array(sorted(model_data["Date"].unique()))

    train_end = int(len(unique_dates) * 0.60)
    validation_end = int(len(unique_dates) * 0.80)

    train_date = unique_dates[train_end]
    validation_date = unique_dates[validation_end]

    train_data = model_data[model_data["Date"] < train_date].copy()
    train_dates = np.array(sorted(train_data["Date"].unique()))
    if gap_days and len(train_dates) >= gap_days:
        train_data = train_data[~train_data["Date"].isin(train_dates[-gap_days:])].copy()
    validation_data = model_data[
        (model_data["Date"] >= train_date) & (model_data["Date"] < validation_date)
    ].copy()
    validation_dates = np.array(sorted(validation_data["Date"].unique()))
    if gap_days and len(validation_dates) >= gap_days:
        validation_data = validation_data[
            ~validation_data["Date"].isin(validation_dates[-gap_days:])
        ].copy()
    test_data = model_data[model_data["Date"] >= validation_date].copy()

    return train_data, validation_data, test_data, train_date, validation_date


def sample_rows(df, maximum_rows=None, seed=None):
    """Return all training rows; kept as a helper for readable call sites."""
    # maximum_rows is retained only for compatibility with older scripts.
    # The final analysis deliberately does not subsample training data.
    return df.copy()


def scale_train_test(train_data, test_data):
    """Scale X and y using training data only."""
    x_scaler = StandardScaler()
    y_scaler = StandardScaler()

    x_train = x_scaler.fit_transform(train_data[FEATURE_COLUMNS])
    x_test = x_scaler.transform(test_data[FEATURE_COLUMNS])

    y_train = y_scaler.fit_transform(train_data[[TARGET_COLUMN]]).ravel()
    y_test = test_data[TARGET_COLUMN].to_numpy()

    return x_train, x_test, y_train, y_test, y_scaler


def invert_y_scale(predictions, y_scaler):
    """Return predictions to original return units."""
    return y_scaler.inverse_transform(np.asarray(predictions).reshape(-1, 1)).ravel()


def calculate_metrics(y_true, y_pred, model_name, historical_mean):
    """Calculate errors, including R-squared against historical-mean forecasts."""
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    benchmark = np.asarray(historical_mean, dtype=float)
    if benchmark.ndim == 0:
        benchmark = np.full(len(y_true), float(benchmark))
    if len(benchmark) != len(y_true):
        raise ValueError("Benchmark predictions must match the evaluation rows.")
    benchmark_error = np.sum((y_true - benchmark) ** 2)
    model_error = np.sum((y_true - y_pred) ** 2)
    return {
        "Model": model_name,
        "RMSE": np.sqrt(mean_squared_error(y_true, y_pred)),
        "MAE": mean_absolute_error(y_true, y_pred),
        "R2": r2_score(y_true, y_pred),
        "R2_Expanding_Mean": 1 - model_error / benchmark_error if benchmark_error > 0 else np.nan,
        "Direction_Accuracy": np.mean(np.sign(y_true) == np.sign(y_pred)),
        "Always_Up_Accuracy": np.mean(y_true > 0),
        "Test_Rows": len(y_true),
    }


def record_predictions(test_rows, predictions, model_name):
    """Keep date- and ticker-level forecasts for dependence-aware forecast tests."""
    if not {"Date", "Ticker"}.issubset(test_rows.columns):
        return
    saved = test_rows[["Date", "Ticker", TARGET_COLUMN]].copy()
    saved = saved.rename(columns={TARGET_COLUMN: "Actual"})
    saved["Prediction"] = np.asarray(predictions)
    saved["Model"] = model_name
    PREDICTION_ROWS.extend(saved.to_dict("records"))


def training_mean_benchmark(train_data, test_data):
    """Forecast with an expanding mean whose five-day outcomes have matured."""
    global TRAINING_MEAN_FORECASTS

    train_rows = train_data[["Date", "Ticker", TARGET_COLUMN]].copy()
    train_rows["Is_Test"] = False
    train_rows["Test_Order"] = -1
    test_rows = test_data[["Date", "Ticker", TARGET_COLUMN]].copy()
    test_rows["Is_Test"] = True
    test_rows["Test_Order"] = np.arange(len(test_rows))
    combined = pd.concat([train_rows, test_rows], ignore_index=True)
    combined["Date"] = pd.to_datetime(combined["Date"])
    combined = combined.sort_values(["Ticker", "Date"]).reset_index(drop=True)

    # A target dated five rows earlier is observable today; newer outcomes
    # have not finished and must not enter the historical-average forecast.
    combined["Benchmark"] = combined.groupby("Ticker")[TARGET_COLUMN].transform(
        lambda values: values.shift(TARGET_HORIZON_DAYS).expanding().mean()
    )
    test_forecasts = combined[combined["Is_Test"]].sort_values("Test_Order")
    fallback = train_data.groupby("Ticker")[TARGET_COLUMN].mean()
    test_forecasts = test_forecasts.copy()
    test_forecasts["Benchmark"] = test_forecasts["Benchmark"].fillna(
        test_forecasts["Ticker"].map(fallback)
    ).fillna(train_data[TARGET_COLUMN].mean())

    TRAINING_MEAN_FORECASTS = {
        (row.Ticker, pd.Timestamp(row.Date)): float(row.Benchmark)
        for row in test_forecasts.itertuples(index=False)
    }
    prediction = benchmark_for_rows(test_data)
    record_predictions(test_data, prediction, "Training-Mean Benchmark")
    return calculate_metrics(
        test_data[TARGET_COLUMN], prediction, "Training-Mean Benchmark",
        prediction,
    )


def benchmark_for_rows(rows):
    """Return the already-computed historical-average forecasts in row order."""
    return np.asarray([
        TRAINING_MEAN_FORECASTS[(row.Ticker, pd.Timestamp(row.Date))]
        for row in rows.itertuples(index=False)
    ])


def selected_features_from_coef(coef):
    """Select non-trivial coefficients using a simple relative threshold."""
    max_abs = np.max(np.abs(coef))
    threshold = max(0.02, 0.15 * max_abs)
    return set(np.array(FEATURE_COLUMNS)[np.abs(coef) >= threshold])


def add_selected_rows(selected_rows, model_name, selected, regime="All"):
    """Append selected-feature rows."""
    for feature in sorted(selected):
        selected_rows.append(
            {
                "Model": model_name,
                "Regime": regime,
                "Feature": feature,
            }
        )


def tune_linear_baselines(train_data, validation_data):
    """Choose linear-model penalties using the shared chronological validation block."""
    # The upper end is deliberately broad because the first validation pass
    # preferred the largest values in the narrower grid.
    alphas = np.logspace(-5, 1, 35)
    tuning_rows = []

    def score_lasso_alpha(train_rows, validation_rows, model_name, seed):
        """Try each LASSO penalty and return the one with the lowest validation RMSE."""
        train_sample = sample_rows(train_rows, MAX_GLOBAL_TRAIN_ROWS, seed)
        x_train, x_validation, y_train, _, y_scaler = scale_train_test(
            train_sample, validation_rows
        )
        fitted_alphas, coefficients, _ = lasso_path(
            x_train, y_train, alphas=alphas, max_iter=10000
        )
        predictions_scaled = x_validation @ coefficients
        predictions = y_scaler.inverse_transform(predictions_scaled)
        scores = np.sqrt(np.mean(
            (validation_rows[TARGET_COLUMN].to_numpy()[:, None] - predictions) ** 2,
            axis=0,
        ))
        for alpha, score in zip(fitted_alphas, scores):
            tuning_rows.append({
                "Model": model_name,
                "Alpha": float(alpha),
                "L1_Ratio": np.nan,
                "Validation_RMSE": float(score),
            })
        return float(fitted_alphas[int(np.argmin(scores))])

    LINEAR_TUNING.clear()
    LINEAR_TUNING["Classical LASSO"] = score_lasso_alpha(
        train_data, validation_data, "Classical LASSO", RANDOM_STATE
    )

    # Elastic Net tests the same validation block and a small, explicit grid.
    train_sample = sample_rows(train_data, MAX_GLOBAL_TRAIN_ROWS, RANDOM_STATE)
    x_train, x_validation, y_train, _, y_scaler = scale_train_test(
        train_sample, validation_data
    )
    elastic_best = (np.inf, None, None)
    elastic_alphas = np.logspace(-5, 1, 30)
    for l1_ratio in [0.2, 0.5, 0.8, 0.95]:
        fitted_alphas, coefficients, _ = enet_path(
            x_train, y_train, l1_ratio=l1_ratio,
            alphas=elastic_alphas, max_iter=10000,
        )
        predictions = y_scaler.inverse_transform(x_validation @ coefficients)
        scores = np.sqrt(np.mean(
            (validation_data[TARGET_COLUMN].to_numpy()[:, None] - predictions) ** 2,
            axis=0,
        ))
        for alpha, score in zip(fitted_alphas, scores):
            tuning_rows.append({
                "Model": "Elastic Net",
                "Alpha": float(alpha),
                "L1_Ratio": float(l1_ratio),
                "Validation_RMSE": float(score),
            })
            if score < elastic_best[0]:
                elastic_best = (score, float(alpha), float(l1_ratio))
    LINEAR_TUNING["Elastic Net"] = {
        "alpha": elastic_best[1], "l1_ratio": elastic_best[2]
    }

    # Adaptive LASSO uses a training-only first-stage cross-validation to form
    # feature weights, then selects its second-stage penalty on the same block.
    first_stage = LassoCV(
        alphas=alphas, cv=5, max_iter=20000, random_state=RANDOM_STATE
    ).fit(x_train, y_train)
    weights = 1 / (np.abs(first_stage.coef_) + 0.01)
    weighted_train = x_train / weights
    weighted_validation = x_validation / weights
    adaptive_alphas, adaptive_coefficients, _ = lasso_path(
        weighted_train, y_train, alphas=alphas, max_iter=10000
    )
    adaptive_predictions = y_scaler.inverse_transform(
        weighted_validation @ adaptive_coefficients
    )
    adaptive_scores = np.sqrt(np.mean(
        (validation_data[TARGET_COLUMN].to_numpy()[:, None] - adaptive_predictions) ** 2,
        axis=0,
    ))
    for alpha, score in zip(adaptive_alphas, adaptive_scores):
        tuning_rows.append({
            "Model": "Adaptive LASSO",
            "Alpha": float(alpha),
            "L1_Ratio": np.nan,
            "Validation_RMSE": float(score),
        })
    LINEAR_TUNING["Adaptive LASSO"] = float(
        adaptive_alphas[int(np.argmin(adaptive_scores))]
    )

    # Each regime gets its own penalty, but all choices use the same dates.
    regime_alphas = np.logspace(-5, 1, 30)
    regime_choices = {}
    for regime_index, regime in enumerate(REGIME_ORDER):
        regime_train = train_data[train_data["Regime"] == regime]
        regime_validation = validation_data[validation_data["Regime"] == regime]
        if regime_train.empty or regime_validation.empty:
            continue
        regime_sample = sample_rows(
            regime_train, MAX_REGIME_TRAIN_ROWS,
            RANDOM_STATE + regime_index,
        )
        x_train_r, x_validation_r, y_train_r, _, y_scaler_r = scale_train_test(
            regime_sample, regime_validation
        )
        fitted_regime_alphas, regime_coefficients, _ = lasso_path(
            x_train_r, y_train_r, alphas=regime_alphas, max_iter=10000
        )
        regime_predictions = y_scaler_r.inverse_transform(
            x_validation_r @ regime_coefficients
        )
        regime_scores = np.sqrt(np.mean(
            (regime_validation[TARGET_COLUMN].to_numpy()[:, None] - regime_predictions) ** 2,
            axis=0,
        ))
        for alpha, score in zip(fitted_regime_alphas, regime_scores):
            tuning_rows.append({
                "Model": f"Regime-specific LASSO: {regime}",
                "Alpha": float(alpha),
                "L1_Ratio": np.nan,
                "Validation_RMSE": float(score),
            })
        regime_choices[regime] = float(
            fitted_regime_alphas[int(np.argmin(regime_scores))]
        )
    LINEAR_TUNING["Regime-specific LASSO"] = regime_choices
    return pd.DataFrame(tuning_rows)


def train_lasso(train_data, test_data, selected_rows):
    """Refit global LASSO with the penalty selected on validation dates."""
    train_sample = sample_rows(train_data, MAX_GLOBAL_TRAIN_ROWS, RANDOM_STATE)
    x_train, x_test, y_train, y_test, y_scaler = scale_train_test(train_sample, test_data)

    if "Classical LASSO" in LINEAR_TUNING:
        model = Lasso(alpha=LINEAR_TUNING["Classical LASSO"], max_iter=20000)
    else:
        model = LassoCV(
        alphas=np.logspace(-5, 1, 35), cv=5, max_iter=50000,
            random_state=RANDOM_STATE,
        )
    model.fit(x_train, y_train)

    predictions = invert_y_scale(model.predict(x_test), y_scaler)
    record_predictions(test_data, predictions, "Classical LASSO")
    selected = selected_features_from_coef(model.coef_)
    add_selected_rows(selected_rows, "Classical LASSO", selected)

    return calculate_metrics(y_test, predictions, "Classical LASSO", benchmark_for_rows(test_data))


def train_elastic_net(train_data, test_data, selected_rows):
    """Refit Elastic Net with the settings selected on validation dates."""
    train_sample = sample_rows(train_data, MAX_GLOBAL_TRAIN_ROWS, RANDOM_STATE)
    x_train, x_test, y_train, y_test, y_scaler = scale_train_test(train_sample, test_data)

    if "Elastic Net" in LINEAR_TUNING:
        settings = LINEAR_TUNING["Elastic Net"]
        model = ElasticNet(
            alpha=settings["alpha"], l1_ratio=settings["l1_ratio"], max_iter=20000
        )
    else:
        model = ElasticNetCV(
            l1_ratio=[0.2, 0.5, 0.8, 0.95],
            alphas=np.logspace(-5, -2, 30),
            cv=5, max_iter=20000, random_state=RANDOM_STATE,
        )
    model.fit(x_train, y_train)

    predictions = invert_y_scale(model.predict(x_test), y_scaler)
    record_predictions(test_data, predictions, "Elastic Net")
    selected = selected_features_from_coef(model.coef_)
    add_selected_rows(selected_rows, "Elastic Net", selected)

    return calculate_metrics(y_test, predictions, "Elastic Net", benchmark_for_rows(test_data))


def train_adaptive_lasso(train_data, test_data, selected_rows):
    """Train a simple two-stage adaptive LASSO."""
    train_sample = sample_rows(train_data, MAX_GLOBAL_TRAIN_ROWS, RANDOM_STATE)
    x_train, x_test, y_train, y_test, y_scaler = scale_train_test(train_sample, test_data)

    first_stage = LassoCV(
        alphas=np.logspace(-5, -2, 35),
        cv=5,
        max_iter=20000,
        random_state=RANDOM_STATE,
    )
    first_stage.fit(x_train, y_train)

    weights = 1 / (np.abs(first_stage.coef_) + 0.01)
    weighted_x_train = x_train / weights
    weighted_x_test = x_test / weights

    if "Adaptive LASSO" in LINEAR_TUNING:
        second_stage = Lasso(
            alpha=LINEAR_TUNING["Adaptive LASSO"], max_iter=20000
        )
    else:
        second_stage = LassoCV(
            alphas=np.logspace(-5, 1, 35), cv=5, max_iter=50000,
            random_state=RANDOM_STATE + 1,
        )
    second_stage.fit(weighted_x_train, y_train)

    coef = second_stage.coef_ / weights
    predictions = invert_y_scale(weighted_x_test @ second_stage.coef_, y_scaler)
    record_predictions(test_data, predictions, "Adaptive LASSO")
    selected = selected_features_from_coef(coef)
    add_selected_rows(selected_rows, "Adaptive LASSO", selected)

    return calculate_metrics(y_test, predictions, "Adaptive LASSO", benchmark_for_rows(test_data))


def train_standard_bayesian_lasso(train_data, test_data, selected_rows):
    """Train global Bayesian LASSO."""
    train_sample = sample_rows(train_data, MAX_GLOBAL_TRAIN_ROWS, RANDOM_STATE)
    x_train, x_test, y_train, y_test, y_scaler = scale_train_test(train_sample, test_data)

    model = BayesianLassoGibbs(
        lambda_value=LAMBDA_0,
        n_iterations=MCMC_ITERATIONS,
        burn_in=BURN_IN,
        thin=THIN,
        random_state=RANDOM_STATE,
    )
    model.fit(x_train, y_train)

    predictions = invert_y_scale(model.predict(x_test), y_scaler)
    record_predictions(test_data, predictions, "Standard Bayesian LASSO")
    selected = selected_features_from_coef(model.coef_)
    add_selected_rows(selected_rows, "Standard Bayesian LASSO", selected)

    return calculate_metrics(y_test, predictions, "Standard Bayesian LASSO", benchmark_for_rows(test_data))


def train_regime_lasso(train_data, test_data, selected_rows):
    """Train separate classical LASSO models by regime."""
    predictions = []

    for regime in REGIME_ORDER:
        regime_train = train_data[train_data["Regime"] == regime].copy()
        regime_test = test_data[test_data["Regime"] == regime].copy()

        if regime_train.empty or regime_test.empty:
            continue

        train_sample = sample_rows(
            regime_train,
            MAX_REGIME_TRAIN_ROWS,
            RANDOM_STATE + REGIME_ORDER.index(regime),
        )
        x_train, x_test, y_train, y_test, y_scaler = scale_train_test(train_sample, regime_test)

        selected_regime_alphas = LINEAR_TUNING.get("Regime-specific LASSO", {})
        alpha = selected_regime_alphas.get(regime)
        if alpha is None:
            model = LassoCV(
                alphas=np.logspace(-5, 1, 30), cv=5, max_iter=20000,
                random_state=RANDOM_STATE + REGIME_ORDER.index(regime),
            )
        else:
            model = Lasso(alpha=alpha, max_iter=20000)
        model.fit(x_train, y_train)

        regime_predictions = invert_y_scale(model.predict(x_test), y_scaler)
        record_predictions(regime_test, regime_predictions, "Regime-specific LASSO")
        frame = regime_test[["Date", "Ticker", TARGET_COLUMN]].copy()
        frame["Prediction"] = regime_predictions
        predictions.append(frame)

        selected = selected_features_from_coef(model.coef_)
        add_selected_rows(selected_rows, "Regime-specific LASSO", selected, regime)

    all_predictions = pd.concat(predictions, ignore_index=True)
    return calculate_metrics(
        all_predictions[TARGET_COLUMN],
        all_predictions["Prediction"],
        "Regime-specific LASSO",
        benchmark_for_rows(all_predictions),
    )


def train_regime_bayesian_model(train_data, test_data, selected_rows, lambda_matrix, model_name):
    """Train one weighted Bayesian LASSO per regime."""
    predictions = []

    for regime in REGIME_ORDER:
        regime_train = train_data[train_data["Regime"] == regime].copy()
        regime_test = test_data[test_data["Regime"] == regime].copy()

        if regime_train.empty or regime_test.empty:
            continue

        train_sample = sample_rows(
            regime_train,
            MAX_REGIME_TRAIN_ROWS,
            RANDOM_STATE + REGIME_ORDER.index(regime),
        )
        x_train, x_test, y_train, y_test, y_scaler = scale_train_test(train_sample, regime_test)

        model = WeightedBayesianLassoGibbs(
            lambda_values=lambda_matrix[regime].loc[FEATURE_COLUMNS].to_numpy(),
            n_iterations=MCMC_ITERATIONS,
            burn_in=BURN_IN,
            thin=THIN,
            random_state=RANDOM_STATE + 100 + REGIME_ORDER.index(regime),
        )
        model.fit(x_train, y_train)

        regime_predictions = invert_y_scale(model.predict(x_test), y_scaler)
        record_predictions(regime_test, regime_predictions, model_name)
        frame = regime_test[["Date", "Ticker", TARGET_COLUMN]].copy()
        frame["Prediction"] = regime_predictions
        predictions.append(frame)

        selected = selected_features_from_coef(model.coef_)
        add_selected_rows(selected_rows, model_name, selected, regime)

    all_predictions = pd.concat(predictions, ignore_index=True)
    return calculate_metrics(
        all_predictions[TARGET_COLUMN],
        all_predictions["Prediction"],
        model_name,
        benchmark_for_rows(all_predictions),
    )


def z_score(series):
    """Population z-score."""
    return (series - series.mean()) / series.std(ddof=0)


def calculate_regime_uncertainty(train_data):
    """Calculate U_r from training data only."""
    market = train_data[train_data["Ticker"] == MARKET_TICKER].copy()

    rows = []
    for regime in REGIME_ORDER:
        regime_rows = market[market["Regime"] == regime]
        volatility = regime_rows[TARGET_COLUMN].std()

        ordered = market.sort_values("Date")
        same_regime_days = ordered[
            (ordered["Regime"] == regime) & (ordered["Regime"].shift(-1) == regime)
        ]
        total_regime_days = ordered[ordered["Regime"] == regime]
        persistence = len(same_regime_days) / len(total_regime_days) if len(total_regime_days) else 0

        rows.append(
            {
                "Regime": regime,
                "Volatility": volatility,
                "Persistence": persistence,
            }
        )

    table = pd.DataFrame(rows)
    table["Instability"] = 1 - table["Persistence"]
    table["U_r"] = z_score(table["Volatility"]) + z_score(table["Instability"])
    return table


def calculate_feature_evidence(train_data):
    """Estimate feature evidence I_jr using absolute training correlations."""
    rows = []

    for regime in REGIME_ORDER:
        regime_rows = train_data[train_data["Regime"] == regime]

        for feature in FEATURE_COLUMNS:
            correlation = regime_rows[feature].corr(regime_rows[TARGET_COLUMN])
            if pd.isna(correlation):
                correlation = 0.0

            rows.append(
                {
                    "Regime": regime,
                    "Feature": feature,
                    "Raw_Evidence": abs(correlation),
                }
            )

    evidence = pd.DataFrame(rows)
    min_value = evidence["Raw_Evidence"].min()
    max_value = evidence["Raw_Evidence"].max()
    evidence["I_jr"] = (evidence["Raw_Evidence"] - min_value) / (max_value - min_value)

    matrix = evidence.pivot(index="Feature", columns="Regime", values="I_jr")
    return matrix[REGIME_ORDER]


def calculate_lambda_matrix(uncertainty, evidence, mode, lambda_0=None):
    """Create lambda_jr for full prior or ablation variants."""
    base_lambda = LAMBDA_0 if lambda_0 is None else float(lambda_0)
    u_values = uncertainty.set_index("Regime")["U_r"]
    lambda_matrix = evidence.copy().astype(float)

    for regime in REGIME_ORDER:
        if mode == "full":
            lambda_matrix[regime] = base_lambda * (
                np.exp(GAMMA * u_values.loc[regime])
                / ((evidence[regime] + EPSILON) ** DELTA)
            )
        elif mode == "uncertainty_only":
            lambda_matrix[regime] = base_lambda * np.exp(GAMMA * u_values.loc[regime])
        elif mode == "evidence_only":
            lambda_matrix[regime] = base_lambda / ((evidence[regime] + EPSILON) ** DELTA)
        elif mode == "constant":
            lambda_matrix[regime] = base_lambda
        else:
            raise ValueError(f"Unknown lambda mode: {mode}")

    return lambda_matrix


def save_outputs(model_results, selected_features, uncertainty, evidence):
    """Save all robust validation outputs."""
    OUTPUT_DIR.mkdir(exist_ok=True)

    model_file = OUTPUT_DIR / "real_data_stronger_baselines.csv"
    selected_file = OUTPUT_DIR / "real_data_selected_features.csv"
    uncertainty_file = OUTPUT_DIR / "real_data_uncertainty_scores.csv"
    evidence_file = OUTPUT_DIR / "real_data_feature_evidence.csv"
    interpretation_file = OUTPUT_DIR / "real_data_validation_interpretation.txt"

    model_results.round(6).to_csv(model_file, index=False)
    selected_features.to_csv(selected_file, index=False)
    uncertainty.round(6).to_csv(uncertainty_file, index=False)
    evidence.round(6).to_csv(evidence_file)

    lines = []
    lines.append("ROBUST REAL-DATA VALIDATION")
    lines.append("")
    lines.append("Purpose:")
    lines.append("Compare stronger baselines and ablate the proposed prior.")
    lines.append("")
    lines.append("Model results:")
    lines.append(model_results.round(6).to_string(index=False))
    lines.append("")
    lines.append("Interpretation:")
    lines.append(
        "If the full prior beats the uncertainty-only and evidence-only variants, "
        "both parts of the proposed formula are useful."
    )
    lines.append(
        "If simpler baselines beat the proposed model on real data, the result "
        "should be explained using the weak-regime simulation finding."
    )

    interpretation_file.write_text("\n".join(lines), encoding="utf-8")

    return {
        "models": model_file,
        "selected": selected_file,
        "uncertainty": uncertainty_file,
        "evidence": evidence_file,
        "interpretation": interpretation_file,
    }


def main():
    global LAMBDA_0, GAMMA, DELTA, EPSILON
    PREDICTION_ROWS.clear()
    print("ROBUST REAL-DATA VALIDATION")
    print("Step 1: stronger baselines plus ablation study")

    selected_config_file = DATA_DIR / "bayesian_lambda0_tuning" / "selected_model_config.json"
    selected_lambda_file = DATA_DIR / "bayesian_lambda0_tuning" / "selected_lambda0.txt"
    if selected_config_file.exists():
        config = json.loads(selected_config_file.read_text(encoding="utf-8"))
        LAMBDA_0 = float(config["lambda0"])
        GAMMA = float(config["gamma"])
        DELTA = float(config["delta"])
        EPSILON = float(config["epsilon"])
    elif selected_lambda_file.exists():
        LAMBDA_0 = float(selected_lambda_file.read_text(encoding="utf-8").strip())
    print(f"Shared lambda0={LAMBDA_0:g}; gamma={GAMMA:g}; delta={DELTA:g}; epsilon={EPSILON:g}")

    raw_data = load_data()
    data_with_features = add_research_features(raw_data)
    model_data = prepare_model_data(data_with_features)

    train_data, validation_data, test_data, train_date, validation_date = split_train_validation_test(
        model_data
    )

    # Fit the regime model on the early training block so that every linear
    # baseline is tuned on the same later validation dates as the Bayesian grid.
    tuning_train, tuning_validation = relabel_split_with_train_hmm(
        train_data, validation_data
    )
    linear_tuning_results = tune_linear_baselines(
        tuning_train, tuning_validation
    )
    print("\nLinear baseline settings selected on the common validation block:")
    print(pd.DataFrame([
        {"Model": "Classical LASSO", "Settings": LINEAR_TUNING["Classical LASSO"]},
        {"Model": "Elastic Net", "Settings": LINEAR_TUNING["Elastic Net"]},
        {"Model": "Adaptive LASSO", "Settings": LINEAR_TUNING["Adaptive LASSO"]},
        {"Model": "Regime-specific LASSO", "Settings": LINEAR_TUNING["Regime-specific LASSO"]},
    ]).to_string(index=False))

    # Use train + validation for the final comparison after the split is fixed.
    final_train = pd.concat([train_data, validation_data], ignore_index=True)
    final_train, test_data = relabel_split_with_train_hmm(final_train, test_data)

    print(f"\nRows available: {len(model_data)}")
    print(f"Training rows: {len(final_train)}")
    print(f"Testing rows: {len(test_data)}")
    print(f"Initial train end date: {pd.Timestamp(train_date).date()}")
    print(f"Final test start date: {pd.Timestamp(validation_date).date()}")

    selected_rows = []
    result_rows = []

    # Keep a simple historical-average forecast beside every fitted model.
    result_rows.append(training_mean_benchmark(final_train, test_data))

    print("\nTraining Classical LASSO")
    result_rows.append(train_lasso(final_train, test_data, selected_rows))

    print("Training Elastic Net")
    result_rows.append(train_elastic_net(final_train, test_data, selected_rows))

    print("Training Adaptive LASSO")
    result_rows.append(train_adaptive_lasso(final_train, test_data, selected_rows))

    print("Training Regime-specific LASSO")
    result_rows.append(train_regime_lasso(final_train, test_data, selected_rows))

    print("Training Standard Bayesian LASSO")
    result_rows.append(train_standard_bayesian_lasso(final_train, test_data, selected_rows))

    uncertainty = calculate_regime_uncertainty(final_train)
    evidence = calculate_feature_evidence(final_train)

    print("Training Regime-specific Bayesian LASSO")
    constant_lambda = calculate_lambda_matrix(uncertainty, evidence, "constant")
    result_rows.append(
        train_regime_bayesian_model(
            final_train,
            test_data,
            selected_rows,
            constant_lambda,
            "Regime-specific Bayesian LASSO",
        )
    )

    print("Training Proposed Prior: uncertainty only")
    uncertainty_lambda = calculate_lambda_matrix(uncertainty, evidence, "uncertainty_only")
    result_rows.append(
        train_regime_bayesian_model(
            final_train,
            test_data,
            selected_rows,
            uncertainty_lambda,
            "Proposed Prior - Uncertainty Only",
        )
    )

    print("Training Proposed Prior: evidence only")
    evidence_lambda = calculate_lambda_matrix(uncertainty, evidence, "evidence_only")
    result_rows.append(
        train_regime_bayesian_model(
            final_train,
            test_data,
            selected_rows,
            evidence_lambda,
            "Proposed Prior - Evidence Only",
        )
    )

    print("Training Proposed Prior: uncertainty + evidence")
    full_lambda = calculate_lambda_matrix(uncertainty, evidence, "full")
    result_rows.append(
        train_regime_bayesian_model(
            final_train,
            test_data,
            selected_rows,
            full_lambda,
            "Proposed Prior - Full",
        )
    )

    for row in result_rows:
        if "Bayesian" in row["Model"] or "Proposed Prior" in row["Model"]:
            row["Lambda0"] = LAMBDA_0
            row["Gamma"] = GAMMA if "Proposed Prior" in row["Model"] else np.nan
            row["Delta"] = DELTA if "Proposed Prior" in row["Model"] else np.nan
            row["Epsilon"] = EPSILON if "Proposed Prior" in row["Model"] else np.nan

    model_results = pd.DataFrame(result_rows)
    model_results = model_results.sort_values("RMSE").reset_index(drop=True)

    selected_features = pd.DataFrame(selected_rows)

    outputs = save_outputs(model_results, selected_features, uncertainty, evidence)
    tuning_output = OUTPUT_DIR / "linear_baseline_validation_tuning.csv"
    linear_tuning_results.to_csv(tuning_output, index=False)
    outputs["linear_baseline_tuning"] = tuning_output
    prediction_file = OUTPUT_DIR / "fixed_split_predictions.csv"
    pd.DataFrame(PREDICTION_ROWS).to_csv(prediction_file, index=False)
    outputs["predictions"] = prediction_file

    print("\nREAL-DATA MODEL COMPARISON")
    print(model_results.round(6).to_string(index=False))

    print("\nSaved files:")
    for path in outputs.values():
        print(path)


if __name__ == "__main__":
    main()
