# Code and results: regime-specific Bayesian LASSO

This archive contains the Python code and result files for the study *Regime-Uncertainty Weighted Bayesian LASSO for Financial Return Prediction*. It does not contain the manuscript.

## What is included

- `important_code/`: scripts for preparing the market data, fitting models, running simulations, validating forecasts, and generating diagnostic and comparison results.
- `data/`: result tables, replication-level simulation outputs, validation scores, and MCMC diagnostics used to check the reported findings.
- `important_code/PLAIN_LANGUAGE_ANALYSIS_GUIDE.md`: an accessible guide to the analysis steps and scripts.

The result tables let readers inspect the reported findings without rerunning the full analysis. The market-price files, derived ticker-level panels, and row-level forecast files are not included in this release. This avoids redistributing vendor-supplied price data; the scripts retrieve the required observations through `yfinance` when run. As a result, downloaded data and exact forecasts can differ if the provider revises its history or ticker coverage.

## Run the analysis

1. Install the packages listed in `important_code/requirements.txt` in a Python environment.
2. Run the data-construction script `important_code/First.py` to retrieve market observations and build the feature data.
3. Run the scripts in the sequence in `important_code/PLAIN_LANGUAGE_ANALYSIS_GUIDE.md` from the archive's root folder.
4. Run `python important_code/final_setting_mcmc_diagnostics.py` to reproduce the four-chain, longer-run MCMC diagnostic check.

The repeated-simulation results use 30 replications in each of seven designs. The paired RMSE test script, `important_code/paired_replication_tests.py`, compares the full prior with regime-specific Bayesian LASSO in every design and adjusts the seven resulting p-values together using Holm's method.

## Source repository and citation

The source repository is <https://github.com/Ushosree177/Regime-Uncertainty-Weighted-Bayesian-LASSO-for-Financial-Return-Prediction>. Cite the frozen Zenodo version using the DOI shown on its record page.
